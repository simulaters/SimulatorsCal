<?php
   // echo "<pre>";
 // print_r($_POST);exit;
@session_start();
   $parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$catgsid = $_POST['catgsid'];
$subsector_id = $_POST['sousSecteur'];
$designation_id = $_POST['fiche'];
$project_id = $_POST['project_id'];
$array_find = array(".pdf",".PDF");
$array_replace = "";
$number_title = str_replace($array_find,$array_replace,$_POST['number_title']);
$siteurl = get_option("siteurl");
$number_link = $_POST['number_link'];
$user_comments	 = $_POST['commentaires'];
$conditions = $_POST['conditions'];
//$mwh_cumac = $_POST['mwh_cumac'];
//$cpe_bonus = $_POST['cpe_bonus'];
$wording = $_POST['wordingid'];
$wmetavalue = $_POST['wmetavalue'];
$condition_id = $_POST['condition_id'];
$condition_valuesid = $_POST['condition_valuesid'];
$user_id = get_current_user_id();
$browserid = session_id();
$partssub = isset($_POST['partssub'])?$_POST['partssub']:"";
$partssubopt = isset($_POST['partssubopt'])?$_POST['partssubopt']:"";
$wpartssub = isset($_POST['wpartssub'])?$_POST['wpartssub']:"";
$wpartssubopt = isset($_POST['wpartssubopt'])?$_POST['wpartssubopt']:"";
$condition_text = isset($_POST['condition_text'])?$_POST['condition_text']:"";
$subcondition_id = isset($_POST['subcondition_id'])?$_POST['subcondition_id']:"";
$subcondition_valuesid = isset($_POST['subcondition_valuesid'])?$_POST['subcondition_valuesid']:"";
$key1='prime_mwhc';
$key2='precarite';
$key3='highprecarite';
$single = true;
$prime_value = "";
if(!empty($user_id)){
	$prime_value= get_user_meta( $user_id, $key1, $single );
	if(!empty($prime_value)){
		$prime_value = $prime_value;
	}else{
		$prime_value = $_POST['prime_value'];
	}	
}else{
	$prime_value = $_POST['prime_value'];
}
//$prime_value = $_POST['prime_value'];
$primecurr = $_POST['primecurr'];
$mwh_cumac = "";
$redirect_viewdetails= get_page_by_path("view-details");
$redirectviewdetailslink = get_permalink($redirect_viewdetails->ID);
$c1 = "";
$c2 = "";
$c3 = "";
$numbertitlearray = array("AGRI-TH-104-010418","IND-UT-117-010418");
$numbertitlearray1 = array("BAR-TH-145");
$numbertitlearray2 = array("TRA-EQ-111");
$currency_find = array(","," ");
$currency_replace = array(".","");
if(!empty($designation_id)){
		if(count($_POST['wmetavalue'])>0){
		$arrays = array();
		$arrays2 = array();
		$arrays3 = array();
		for($k=0;$k<count($_POST['wmetavalue']);$k++){	
				if(!empty($_POST['wmetavalue'][$k])&& strstr($_POST['wmetavalue'][$k],"-")){
						$wmtas = explode("-",$_POST['wmetavalue'][$k]);
						$wording_meta_id = $wmtas[0];
						$valuemetas = str_replace($currency_find,$currency_replace,$wmtas[1]);
						$arrays[] = preg_replace('/\s+/', '',$valuemetas);
					}else if(!strstr($_POST['wmetavalue'][$k],"-")){
					    if(!empty($_POST['wmetavalue'][$k])){
						    $valuemetas2 = str_replace($currency_find,$currency_replace,$_POST['wmetavalue'][$k]);
					    }else{
					        $valuemetas2 = 0;
					    }
						$arrays2[] = $valuemetas2;
				}
		}
		
		if(count($_POST['condition_valuesid'])>0){
		$arrays3 = array();
		for($k=0;$k<count($_POST['condition_valuesid']);$k++){	
				if(!empty($_POST['condition_valuesid'][$k])&& strstr($_POST['condition_valuesid'][$k],"-")){
						$conds = explode("-",$_POST['condition_valuesid'][$k]);
						$condition_meta_id = $conds[0];
						$valueconds1 = preg_replace('/\s+/', '',$conds[1]);
						$valueconds = str_replace($currency_find,$currency_replace,$valueconds1);
						$arrays3[] = $valueconds;
					}
		}
		 
	}
		
		/*if(!isset($_POST['condition_valuesid'])){
			$c1 = array_product(array_filter($arrays));
			$c2 = array_product(array_filter($arrays2));
			$mwh_cumac = $c1*$c2;
		}else if(isset($_POST['condition_valuesid'])){
			$c2 = array_product($arrays2);
			$c3 = array_product($arrays3);
			$mwh_cumac = $c2*$c3;
		}*/
		if(!empty($arrays) && empty($arrays2) && empty($arrays3)){
			$c1 = array_product(array_filter($arrays));
			$mwh_cumac = $c1;
			 	
		}else if(empty($arrays) && !empty($arrays2) && empty($arrays3)){
			$c2 = array_product(array_filter($arrays2));
			if(in_array($number_title,$numbertitlearray2)){
				$wpartssub1 =preg_replace('/\s+/', '',str_replace($currency_find,$currency_replace,$wpartssub[0]));
				
				$wpartssub2 =preg_replace('/\s+/', '',str_replace($currency_find,$currency_replace,$wpartssub[1]));
				$c2 = $c2-$wpartssub2;
				$c1 = $wpartssub1;
				$mwh_cumac = $c1*$c2;
			}else{
				$mwh_cumac = $c2;
			}
		}else if(empty($arrays) && empty($arrays2) && !empty($arrays3)){
			$c3 = array_product(array_filter($arrays3));
			$mwh_cumac = $c3;
		}else if(!empty($arrays) && !empty($arrays2) && empty($arrays3)){
			if(in_array($number_title,$numbertitlearray)){
				$c1 = array_product(array_filter($arrays));
				$wpartssub =preg_replace('/\s+/', '',str_replace($currency_find,$currency_replace,$wpartssub[0]));
				$c2 = ($wpartssub*$arrays2[0])-$arrays2[1];
				$mwh_cumac = $c1*$c2;
			}else if(in_array($number_title,$numbertitlearray1)){
				$c1 = $arrays[1]-$arrays[0];
				$wpartssub =preg_replace('/\s+/', '',str_replace($currency_find,$currency_replace,$wpartssub[0]));
				$c2 = ($wpartssub*$arrays2[0]);
				$mwh_cumac = $c1*$c2;
			}else{
				$c1 = array_product(array_filter($arrays));
				$c2 = array_product(array_filter($arrays2));
				$mwh_cumac = $c1*$c2;
			}
		}else if(empty($arrays) && !empty($arrays2) && !empty($arrays3)){
			$c2 = array_product(array_filter($arrays2));
			$c3 = array_product(array_filter($arrays3));
			$mwh_cumac = $c2*$c3;
		}else if(!empty($arrays) && empty($arrays2) && !empty($arrays3)){
			$c1 = array_product(array_filter($arrays));
			$c3 = array_product(array_filter($arrays3));
			$mwh_cumac = $c1*$c3;
		}else if(!empty($arrays) && !empty($arrays2) && !empty($arrays3)){
			//echo "<pre>";
			//$arrays = array(0);
			//print_r($arrays);
			//print_r($arrays2);
			//print_r($arrays3);
			/*if (array_filter($arrays)){
				$c1 = array_product($arrays);				 	
			}else if ($arrays[0]==0){
				 $c1 = 0;				 			 
			}
			if (array_filter($arrays2)){
				 $c2 = array_product($arrays2);				 			 
			}else if ($arrays2[0]==0){
				 $c2 = 0;				 			 
			}
			if (array_filter($arrays3)){
				 $c3 = array_product($arrays3);
			} 
			if(!empty($c1)){
				 $mwh_cumac = $mwh_cumac*$c1;
			}
			if(!empty($c1) && !empty($c2) && !empty($c3)){
				 $mwh_cumac =  $c1*$c2*$c3;
			}else if(empty($c1) && !empty($c2) && !empty($c3)){
				 $mwh_cumac =  $c2*$c3;
			}else if($c2==0 && !empty($c3)){
				 $mwh_cumac =  $c2*$c3;
			}else if($c1==0 && $c2==0 && !empty($c3)){
				 $mwh_cumac =  $c1*$c2*$c3;
			}*/

			$c1 = array_product(array_filter($arrays));
			$c2 = array_product($arrays2);
			$c3 = array_product(array_filter($arrays3));
			$mwh_cumac = $c1*$c2*$c3;	
			 
		}
		
		if(!empty($partssub) && !in_array($number_title,$numbertitlearray) &&  !in_array($number_title,$numbertitlearray1) && !in_array($number_title,$numbertitlearray2)){
			if($partssubopt=="Add"){
				$mwh_cumac =  $mwh_cumac+$partssub ;
			}
			if($partssubopt=="Sub"){
				$mwh_cumac =  $mwh_cumac-$partssub ;
			}
			if($partssubopt=="Mult"){
				$mwh_cumac =  $mwh_cumac*$partssub ;
			}
			if($partssubopt=="Div"){
				$mwh_cumac =  $mwh_cumac/$partssub ;
			}
			
		}
		if(!empty($wpartssub) && !in_array($number_title,$numbertitlearray) && !in_array($number_title,$numbertitlearray1) && !in_array($number_title,$numbertitlearray2)){
			$wpartssub = preg_replace('/\s+/', '',str_replace($currency_find,$currency_replace,$wpartssub[0]));
			if($wpartssubopt=="Add"){
				$mwh_cumac = $mwh_cumac+$wpartssub;
			}
			if($wpartssubopt=="Sub"){
				$mwh_cumac = $mwh_cumac-$wpartssub;
			}
			if($wpartssubopt=="Mult"){
				$mwh_cumac = $mwh_cumac*$wpartssub;
			}
			if($wpartssubopt=="Div"){
				$mwh_cumac = $mwh_cumac/$wpartssub;
			}			
		}
	}
	 
	if(!empty($condition_text)){
		 $mwh_cumac = $mwh_cumac*$condition_text;
	}
	if(!empty($subcondition_valuesid)){
		$subcondsexplode = explode("-",$_POST['subcondition_valuesid']);
		//print_r($subcondsexplode);exit;
		$subcondsid = $subcondsexplode[0];
		$subcondsvalues = $subcondsexplode[1];
		$conditionsvals = $subcondsexplode[2];
		$SQLCONDSVALS = "SELECT mc_value FROM wp_meta_conditions_values WHEER id='".$conditionsvals."'";
		$rsCondsVals = $wpdb->get_results($SQLCONDSVALS);
		$condsvals = $rsCondsVals[0]->mc_value;
		if(!empty($condsvals)){
			$mwh_cumac = $mwh_cumac*$subcondsvalues*$condsvals;
		}else{
			$mwh_cumac = $mwh_cumac*$subcondsvalues;
		}
	}
	
	$prime_value_cal = ($prime_value*$mwh_cumac)/1000;
	$SQL = "INSERT INTO wp_project_meta SET user_id='".$user_id."',browserid='".$browserid."',sector_id='".$catgsid."',subsector_id='".esc_sql($subsector_id)."',designation_id='".esc_sql($designation_id)."',project_id='".esc_sql($project_id)."',number_title='".esc_sql($number_title)."',number_link='".esc_sql($number_link)."'
	,conditions='".esc_sql($conditions)."',prime_value_cal='".$prime_value_cal."',primecurr='".$primecurr."',mwh_cumac='".esc_sql($mwh_cumac)."'";
	$wpdb->query($SQL);
	$project_meta_id = $wpdb->insert_id;
	if(count($_POST['wordingid'])>0){
		$wording_meta_id = "";
		$value = "";
		for($i=0;$i<count($_POST['wordingid']);$i++){
			if(!empty($_POST['wordingid'][$i])){
				$wording = $_POST['wordingid'][$i];
				$wordingmeta = $_POST['wmetavalue'][$i];
				if(!empty($wordingmeta)&& strstr($wordingmeta,"-")){
					$wmta = explode("-",$wordingmeta);
					$wording_meta_id = $wmta[0];
					$value = $wmta[1];
					$condsexists = $wmta[2];
				}else if(!empty($wordingmeta)&& !strstr($wordingmeta,"-")){
				    $wording_meta_id = 0;
					$value = str_replace($currency_find,$currency_replace,$wordingmeta);
				}else{
				    
				     $wording_meta_id = 0;
					 $value = 0;
				}							
				$SQLMETA = "INSERT INTO wp_project_meta_wording SET project_id='".$project_id."',project_meta_id='".$project_meta_id."',wording='".$wording."',wording_meta_id='".$wording_meta_id."',value='".$value."'";
				$wpdb->query($SQLMETA);
				$wording_meta_wording_id = $wpdb->insert_id;
				if(!empty($wording_meta_id) && $condsexists=="Yes"){
					//save_conditions();
					if(count($_POST['condition_id'])>0){
						for($kk=0;$kk<count($_POST['condition_id']);$kk++){
							if(!empty($_POST['condition_id'][$kk])){
								$condition_id = $_POST['condition_id'][$kk];
								$conditionsmeta = $_POST['condition_valuesid'][$kk];
								if(!empty($conditionsmeta)&& strstr($conditionsmeta,"-")){
									$conds = explode("-",$conditionsmeta);
									$conditions_valueids = $conds[0];
									$consddacavle = $conds[1];	
								}
								$SQLMETACONDS = "INSERT INTO wp_project_meta_conditions SET project_id='".$project_id."',project_meta_id='".$project_meta_id."',wording='".$wording."',wording_meta_id='".$wording_meta_id."',wording_meta_wording_id='".$wording_meta_wording_id."',condition_id='".$condition_id."',conditions_valueids='".$conditions_valueids."',consddacavle='".$consddacavle."'";
								$wpdb->query($SQLMETACONDS);
							}
						}
						if(!empty($condition_text)){
							$condition_ids = $_POST['condition_textid'];
							$consddacavles = $_POST['condition_text'];
							$SQLMETACONDSTEXT = "INSERT INTO wp_project_meta_conditions SET project_id='".$project_id."',project_meta_id='".$project_meta_id."',wording='".$wording."',wording_meta_id='".$wording_meta_id."',wording_meta_wording_id='".$wording_meta_wording_id."',condition_id='".$condition_ids."',consddacavle='".$consddacavles."'";
							$wpdb->query($SQLMETACONDSTEXT);
						}
						if(isset($_POST['subcondition_id']) && !empty($_POST['subcondition_id'])){
							$subcondition_id = $_POST['subcondition_id'];
							$subcondsexplode = explode("-",$_POST['subcondition_valuesid']);
							$subconditions_valueids = $subcondsexplode[0];
							$subconsddacavle = $subcondsexplode[1];
							$condition_ids = $subcondsexplode[2];
							$subparents_id = $subcondsexplode[3];
							$SQLMETASUBCONDSTEXT = "INSERT INTO wp_project_meta_subconditions SET project_id='".$project_id."',project_meta_id='".$project_meta_id."',wording='".$wording."',wording_meta_id='".$wording_meta_id."',wording_meta_wording_id='".$wording_meta_wording_id."',condition_id='".$condition_ids."',subparents_id='".$subparents_id."',subcondition_id='".$subcondition_id."',subconditions_valueids='".$subconditions_valueids."',subconsddacavle='".$subconsddacavle."'";
							$wpdb->query($SQLMETASUBCONDSTEXT);
						}
					}	
				}	
			}
		}
	}
	
}

function get_subsector($subsector_id){
	global $wpdb;
	$SQL = "SELECT category_name FROM wp_subcategory WHERE id='".$subsector_id."'";
	$rsSubcat = $wpdb->get_results($SQL);
	$subsectors = $rsSubcat[0]->category_name;
	return $subsectors;
}

function get_designations($designation_id){
	global $wpdb;
	$SQL = "SELECT des_name FROM wp_designations WHERE id='".$designation_id."'";
	$rsDesc = $wpdb->get_results($SQL);
	$desname = $rsDesc[0]->des_name;
	return $desname;
}

function get_meta_conditions($wording_meta_wording_id,$wording_meta_id){
	global $wpdb;
	$rsconditions = "";
	$SQL = "SELECT * FROM wp_project_meta_conditions WHERE wording_meta_id='".$wording_meta_id."' AND wording_meta_wording_id='".$wording_meta_wording_id."'";
	$rsConds = $wpdb->get_results($SQL);
	if(count($rsConds)>0){
		for($i=0;$i<count($rsConds);$i++){
			$SQLCONDS = "SELECT mc_title FROM wp_meta_conditions WHERE id='".$rsConds[$i]->condition_id."'";
			$rsCondsLabel = $wpdb->get_results($SQLCONDS);
			if(!empty($rsConds[$i]->conditions_valueids)){
				$SQLCONDSVALS = "SELECT mc_title FROM wp_meta_conditions_values WHERE id='".$rsConds[$i]->conditions_valueids."'";
				$rsCondsLabelVals = $wpdb->get_results($SQLCONDSVALS);
				$mcndstitles = $rsCondsLabelVals[0]->mc_title;
			}else{
				$mcndstitles = $rsConds[$i]->consddacavle;
			}
			$rsconditions .= '<tr><td>'.stripslashes($rsCondsLabel[0]->mc_title).'</td><td>'.$mcndstitles.'</td></tr>';
		}
	}
	return $rsconditions;
}


function get_wordings($project_meta_id,$designation_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."' ORDER BY id ASC";
	$rsMeta = $wpdb->get_results($SQL);
	//print_r($rsMeta);
	$arraywpmeta = array();
	if(count($rsMeta)>0){
		for($x=0;$x<count($rsMeta);$x++){
			if($rsMeta[$x]->wording_meta_id!=0){
				$arraywpmeta[$x] = $rsMeta[$x]->wording_meta_id."-".$rsMeta[$x]->value;
			}else{
				$arraywpmeta[$x] = $rsMeta[$x]->value;
			}
		}
	}
	
	$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$designation_id."' AND otherparts='No' ORDER BY `desg_id` ASC";
$resultWord = $wpdb->get_results($SQwording);
$meta = "";
$meta1 = "";
$meta2 = "";
if(count($resultWord)>0){
	$wpmetaid = "";
	$wpmetavalues = "";
	$meta .= '<table width="100%">';
	for($y=0;$y<count($resultWord);$y++){
		if($resultWord[$y]->otherparts=="No"){
		$metaselectionsdata = $arraywpmeta[$y];
		if(strstr($metaselectionsdata,"-")){
			$metaselections = explode("-",$metaselectionsdata);
			$wpmetaid = $metaselections[0];
		}else{
			$wpmetavalues = number_format($rsMeta[$y]->value,0," "," ");
		}
		$wmts=$resultWord[$y]->id;
		$SQwordMeta="SELECT * FROM wp_wording_meta WHERE id='".$wpmetaid."' AND word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
		$WMeta = $wpdb->get_results($SQwordMeta);
		$meta .= '<tr><td style="width:97px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
		'.stripslashes($resultWord[$y]->title).'
		</font></font></td>';
		$meta .= '<td class="param-input tac">';
		 if(!empty($WMeta)){
			$arraymetaconsd = array();
			//$meta .= '<select name="wmetavalue[]" onchange=\'return  get_conditions(this.value,"'.$catgsid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$SQLPRODMETACONDS = "SELECT * FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."' AND wording_meta_id='".$wmr->id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				
				if(count($rsProdMetaConditions)>0){	
					$values = $wmr->id;					 				
				$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$values."' ORDER BY is_cond ASC";
				$rsConditions = $wpdb->get_results($SQLCOND);
				if(count($rsConditions)>0){
				$selected = "";
			$array_conds = array();
			$condisids = array();
			$condstextvalues = "";
			 for($x=0;$x<count($rsConditions);$x++){
				if($rsConditions[$x]->is_cond=="Yes"){ 
				$cond_id = $rsConditions[$x]->id;
				$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
				$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
				$condionsvals = '';		
				
				$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
						
			  for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
				$SQLSUBCONDVALUES = "SELECT * FROM wp_project_meta_subconditions WHERE project_meta_id ='".$project_meta_id."' AND subparents_id='".$rsProdMetaConditions[$jj]->condition_id."'";				
				$rsSubConds = $wpdb->get_results($SQLSUBCONDVALUES);
				
				if(count($rsSubConds)>0){
					 $SQLSUBCONDSMETAS = "SELECT wp_cond_meta_cond.cmc_title
										FROM wp_cond_meta_cond
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond.id=wp_project_meta_subconditions.subcondition_id
										WHERE wp_cond_meta_cond.id='".$rsSubConds[0]->subcondition_id."'";
						
					$rsSubCondstitles = $wpdb->get_results($SQLSUBCONDSMETAS);
					
					$SQLSUBCONDSMETAS1 = "SELECT wp_cond_meta_cond_values.cmcv_title
										FROM wp_cond_meta_cond_values
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond_values.id=wp_project_meta_subconditions.subconditions_valueids
										WHERE wp_cond_meta_cond_values.id='".$rsSubConds[0]->subconditions_valueids."'";
						
					$rsSubCondsmetatitles = $wpdb->get_results($SQLSUBCONDSMETAS1);
					$meta2 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubCondstitles[0]->cmc_title.'</font></font></td><td>'.$rsSubCondsmetatitles[0]->cmcv_title.'</td></tr>';
				}
			  
			  
				$meta1 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->mc_title.'</td></tr>';
			 }
				if($x==0){
				$meta1 .= $meta2;
			  }
			 }else if($rsConditions[$x]->is_cond=="No"){
					$cond_id = $rsConditions[$x]->id;
					$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_project_meta_conditions.consddacavle,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
					$meta1 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->consddacavle.'</td></tr>';
				}
			 }	
			}
			}	
			 
				}				
				 
				$meta .=  stripslashes($wmr->title);
			 }
			//$meta .= '</select>';
		}else{
			$meta .= str_replace(".",",",$wpmetavalues);
		}
		 
		$meta .= '</td></tr>';
		} 
	}
		$meta .= $meta1;
		$meta .= '</table>';
 }
	return $meta;
}

$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE browserid='".$browserid."' AND sector_id='".$catgsid."' ORDER BY id DESC LIMIT 1";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);
if(count($rsProdmeta)>0){
	for($i=0;$i<count($rsProdmeta);$i++){
?>
<tr class="sa_tab2" id="trsimuledit<?php echo $rsProdmeta[$i]->id;?>">
<td rowspan="1" width="74">
<?php 
 $subsectors = get_subsector($rsProdmeta[$i]->subsector_id);
echo $subsectors;?>
</td>


<td class="designpdf" rowspan="1"  width="141">
	<?php 
 $designations = get_designations($rsProdmeta[$i]->designation_id);
echo stripslashes($designations);?>
<br>
<a id="pdflink" href="<?php echo $rsProdmeta[$i]->number_link;?>" target="_blank"><?php echo $rsProdmeta[$i]->number_title;?></a>
</td>
<td colspan="2" width="106" valign="top" class="botrf"><?php 
	$wordings = get_wordings($rsProdmeta[$i]->id,$rsProdmeta[$i]->designation_id);
	echo $wordings;?></td>

<td class="" rowspan="1" width="95"><?php echo stripslashes($rsProdmeta[$i]->conditions);?></td>
<td class="" rowspan="1" width="55"><?php echo str_replace(".",",",number_format($rsProdmeta[$i]->mwh_cumac,0," "," "));?></td>
<td class="" rowspan="1" width="55"><?php echo number_format($rsProdmeta[$i]->prime_value_cal,0," "," ")." ".$rsProdmeta[$i]->primecurr;?></td>
<td class="" style="text-align:center;" rowspan="1" width="59"><span class="updt_data" onclick="return edit_project('<?php echo $rsProdmeta[$i]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/edit_data.php','<?php echo $subsector_id;?>','<?php echo $designation_id;?>','<?php echo $project_id;?>','<?php echo $catgsid;?>');">modifier</span>
<a href="<?php echo $redirectviewdetailslink;?>?id=<?php echo $rsProdmeta[$i]->id;?>"><span class="updt_data">Demander ma Prime<br/><?php echo number_format($rsProdmeta[$i]->prime_value_cal,0," "," ")." ".$rsProdmeta[$i]->primecurr;?></span></a>
</td>
</tr>
<?php }
}?>