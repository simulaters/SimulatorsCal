<?php
     echo "<pre>";
     print_r($_POST);exit;
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$catgsid = $_POST['catgsid'];
$subsector_id = $_POST['sousSecteur'];
$designation_id = $_POST['fiche'];
$project_id = $_POST['project_id'];
$project_meta_id = $_POST['project_meta_id'];

function get_subsector($subsector_id){
	global $wpdb;
	$SQL = "SELECT category_name FROM wp_subcategory WHERE id='".$subsector_id."'";
	$rsSubcat = $wpdb->get_results($SQL);
	$subsectors = $rsSubcat[0]->category_name;
	return $subsectors;
}

function get_designations($designation_id){
	global $wpdb;
	$SQL = "SELECT des_name FROM wp_designations WHERE id='".$designation_id."'";
	$rsDesc = $wpdb->get_results($SQL);
	$desname = $rsDesc[0]->des_name;
	return $desname;
}


function get_wordings($project_meta_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."'";
	$rsMeta = $wpdb->get_results($SQL);
	$meta = "";
	$meta_title = "";
	if(count($rsMeta)>0){
		$meta .= '<table with="100%">';
		for($i=0;$i<count($rsMeta);$i++){
			$SQLWording="SELECT title FROM wp_wording WHERE id ='".$rsMeta[$i]->wording."'";
			$resultWord = $wpdb->get_results($SQLWording);
			if(!empty($rsMeta[$i]->wording_meta_id)){			
				$SQWordingMeta="SELECT title FROM wp_wording_meta WHERE id ='".$rsMeta[$i]->wording_meta_id."'";
				$resultWordMeta = $wpdb->get_results($SQWordingMeta);
				$meta_title = $resultWordMeta[0]->title;
			}else {				
				$meta_title = 	$rsMeta[$i]->value;
			}
			
			$meta .= '<tr><td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
			'.$resultWord[0]->title.'
			</font></font>
			</td>';
			$meta .= '<td class="param-input tac">'.$meta_title.'</td></tr>';
		}
			$meta .= '</table>';
	}
	return $meta;
}

$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE id='".$project_meta_id."'";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);
if(count($rsProdmeta)>0){
	for($i=0;$i<count($rsProdmeta);$i++){
?>
<tr id="trsimuledit<?php echo $rsProdmeta[$i]->id;?>">
<td rowspan="1">
<?php 
 $subsectors = get_subsector($rsProdmeta[$i]->subsector_id);
echo $subsectors;?>
</td>


<td class="" rowspan="1"><?php echo $rsProdmeta[$i]->subsector_id;?>
	<?php 
 $designations = get_designations($rsProdmeta[$i]->designation_id);
echo $designations;?>
</td>

<td class=""><?php echo $rsProdmeta[$i]->number_title;?></td>

<td colspan="2"><?php 
	$wordings = get_wordings($rsProdmeta[$i]->id);
	echo $wordings;?></td>

<td class="" rowspan="1"><?php echo $rsProdmeta[$i]->conditions;?></td>
<td class="" rowspan="1"><?php echo $rsProdmeta[$i]->user_comments;?></td>
<td class="" rowspan="1"><?php echo $rsProdmeta[$i]->mwh_cumac;?></td>
<td class="" rowspan="1">0</td>
<td class="" style="text-align:center;" rowspan="1"><span onclick="return edit_project('<?php echo $rsProdmeta[$i]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/edit_data.php','<?php echo $subsector_id;?>','<?php echo $designation_id;?>','<?php echo $project_id;?>','<?php echo $catgsid;?>');">Action</span>
</td>
</tr>
<?php }
}?>