<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
if($_POST["stats"]=="fetchsubcat"){
$q=$_POST["catids"];
$dq=$_POST["dcatid"];
$table = $wpdb->prefix.$_POST['table_name'];
$SQLcatp="SELECT * FROM ".$table."  WHERE subcatid ='$q'";
$result = $wpdb->get_results($SQLcatp);
$catid = $result[0]->catid;
$project_meta_id = $_POST['prjmtaid'];
//print_r($_POST);
$ctprid = $catid."-".$project_meta_id;
echo '<select name="fiche6" style="max-width: 120px;" onchange="getdestinationsedit(this.value,\''.$catid.'\',\''.$ctprid.'\')" id="fiche'.$catid.'-'.$project_meta_id.'">';
echo '<option value=""></option>';
	foreach($result as $row){
		echo "<option value=".$row->id.">" . stripslashes($row->des_name). "</option>";
	}
	echo "</select>";
	echo '<span  id="numbedit'.$dq.'" class="numero-link-holder"></span>';

}
if($_POST["stats"]=="fetchdestinations"){
$DESIGID=$_POST['destiid'];
$SQLcatp="SELECT * FROM wp_designations WHERE id ='$DESIGID'";
$result = $wpdb->get_results($SQLcatp);

$meta_id =$result[0]->id;

//===========Wording============//
$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$meta_id."' ORDER BY `desg_id` ASC";
$resultWord = $wpdb->get_results($SQwording);
$meta = "";
$meta1 = "";
$meta2 = "";
if(count($resultWord)>0){
	$meta .= '<table with="100%">';
	foreach($resultWord as $spt){
		$wmts=$spt->id;
		if($spt->otherparts=="No"){
		$SQwordMeta="SELECT * FROM wp_wording_meta WHERE word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
		$WMeta = $wpdb->get_results($SQwordMeta);
		$meta .= '<tr><td style="width:94px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
		'.$spt->title.'
		</font></font>
		<input type="text" name="wordingid[]" id="wordingid'.$catid.'-'.$project_meta_id.'" value="'.$wmts.'" style="display:none;"/>
		</td>';
		$meta .= '<td class="param-input tac">';
		 if(!empty($WMeta)){
			$counter_meta = 0;
			$first_conditions = "";
			$condionsvals = "";
			$counter_meta_conds = 0;
			$meta .= '<select name="wmetavalue[]" id="wmetavalue'.$catid.'-'.$project_meta_id.'" onchange=\'return  get_conditions(this.value,"'.$catids.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$counter_meta = $counter_meta+1;
				//====Check Meta Conditions==========//
				//If Meta Conditions Exists//
				//If Meta Conditions Exists//
				if($counter_meta==1){
					$meta_id = $wmr->id;
					$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$meta_id."' ORDER BY is_cond ASC";
					$rsConditions = $wpdb->get_results($SQLCOND);
					$first_conditions = "1";
					if(count($rsConditions)>0){
			 for($x=0;$x<count($rsConditions);$x++){
				if($rsConditions[$x]->is_cond=="Yes"){ 
					$cond_id = $rsConditions[$x]->id;
					$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
					$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
					$condionsvals = '<select name="condition_valuesid[]" id="condition_valuesid">';
					 for($aa=0;$aa<count($rsCondValues);$aa++){
						$counter_meta_conds = $counter_meta_conds+1;
						if($counter_meta_conds ==1){
							$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$rsCondValues[$aa]->id."'";
							$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
							if(count($rsSubconds)>0){								
								 for($xx=0;$xx<count($rsSubconds);$xx++){						
									$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
									$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
									if(count($rsSubcondMetas)>0){
										$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
										for($yy=0;$yy<count($rsSubcondMetas);$yy++){
											$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'">'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
										}
										$subcondionsvals .= '</select>';	
									}
									 $meta2 .= '<tr id="trcpconmetas'.$catids.'" class="trcpnditions'.$catids.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubconds[$xx]->cmc_title.'</font></font>
									 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catids.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
									 </td><td>'.$subcondionsvals.'</td></tr>';
								}
							}
						}else{
							$meta2 .= "";
						}
						$condionsvals .= '<option value="'.$rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value.'">'.$rsCondValues[$aa]->mc_title.'</option>';
					 }
					$condionsvals .= '</select>
					<input type="text" name="condition_id[]" id="condition_id'.$catids.'" value="'.$rsConditions[$x]->id.'" style="display:none;"/>';				
				  
					$meta1 .= '<tr class="trcpnditions'.$catids.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$condionsvals.'</td></tr>';
					if($x==0){
						$meta1 .= '<tr id="trconds0-'.$catids.'"style="display:none;"><td colspan="2"></td></tr>';
						$meta1 .= $meta2; 
					}
			 }
			 if($rsConditions[$x]->is_cond=="No"){
				if($rsConditions[$x]->otherparts=="No"){
				 $condsvaltext = '<input type="text" name="condition_text" id="condition_text"/>';
				 $meta1 .= '<tr class="trcpnditions'.$catids.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$condsvaltext.'</td></tr>';
				 $meta1 .= '<input type="hidden" name="condition_textid" id="condition_textid'.$catids.'" value="'.$rsConditions[$x]->id.'"/>';	
				}
				if($rsConditions[$x]->otherparts=="Yes"){
				 $meta1 .= '<tr class="trcpnditions'.$catids.'" style="display:none;"><td><input type="hidden" name="partssub" id="partssub'.$catids.'" value="'.$rsConditions[$x]->mc_value.'"/>
				 <input type="hidden" name="partssubopt" id="partssubopt'.$catids.'" value="'.$rsConditions[$x]->optypes.'"/></td></tr>';
				 }
			 }
			 
			}
			}		
				}
				$meta .=  '<option value="'.$wmr->id.'-'.$wmr->value.'">'.stripslashes($wmr->title).'</option>';
			 }
			$meta .= '</select>';
		}else{
			$meta .= '<input type="text" name="wmetavalue[]" id="wmetavalue'.$catid.'-'.$project_meta_id.'" value=""  min="0" step="1">';
		}
		}else if($spt->otherparts=="Yes"){
			 $meta .= '<input type="text" style="display:none;" name="wpartssub[]" id="wpartssub'.$catids.'" value="'.$spt->word_value.'"/>
				 <input type="hidden" name="wpartssubopt" id="wpartssubopt'.$catids.'" value="'.$spt->optypes.'"/>';
		} 
		$meta .= '</td></tr>';
		if(!empty( $first_conditions)){
			$meta .= "A".$meta1;  	
        }
	}
		$meta .= '<tr id="trconds'.$catids.'" stype="display:none;"><td class="sav_spcl" colspan="2"></td></tr></table>';
 }
 
//===========Wording============//

$target = get_site_url()."/wp-content/plugins/simulate/uploads/".$result[0]->number;
$ns = "";
if($result[0]->number){
	$ns='<a target="_blank" href="'.$target.'"><font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.$result[0]->number.'</font></font></a>';
}
$meta .= '<input type="hidden" name="number_title" id="number_title" value="'.$result[0]->number.'"/><input type="hidden" name="number_link" id="number_link" value="'.$target.'"/>';
$commt = "";
if($result[0]->conditions){
$commt='<font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.stripslashes($result[0]->conditions).'</font></font>';
}
$meta .= '<input type="hidden" name="conditions" id="conditions" value="'.$result[0]->conditions.'"/>';
$this_insert=array('numb'=>$ns,'conditions'=>$result[0]->conditions,'meta'=>$meta);
echo json_encode($this_insert);
}
?>