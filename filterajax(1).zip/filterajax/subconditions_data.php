<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$metaids = explode("-",$_POST['metaids']);
 //print_r($_POST);
$condition_id = $metaids[0];
$catid= $_POST['catid'];
$siteurl = get_option('siteurl');
$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$condition_id."'";
$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
if(count($rsSubconds)>0){								
	for($xx=0;$xx<count($rsSubconds);$xx++){						
		$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
		$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
		if(count($rsSubcondMetas)>0){
			$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
			for($yy=0;$yy<count($rsSubcondMetas);$yy++){
				$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'">'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
			}
				$subcondionsvals .= '</select>';	
			}
			
			echo  $meta2  = '<tr id="trcpconmetas'.$catid.'" class="trcpnditions'.$catid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubconds[$xx]->cmc_title.'</font></font>
									 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catid.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
									 </td><td>'.$subcondionsvals.'</td></tr>';
			}
}else{
	echo "No";
}
?>