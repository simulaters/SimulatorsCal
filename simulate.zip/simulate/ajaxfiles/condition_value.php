<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";
$table_neta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
$mc_ID=$_POST['cond_id'];
$cv_ID=$_POST['cv_ID'];
$buttontext = $_POST['sbmt'];
$formtype = $_POST['wordtype'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if(!empty($cv_ID)){
$SQLcondv = "SELECT * FROM ".$table_neta_conditionsvalue." WHERE cond_id='".$mc_ID."' AND id='".$cv_ID."'";
$condvTPT = $wpdb->get_results($SQLcondv);
$MCVtitle=$condvTPT[0]->mc_title;
$MCVid=$condvTPT[0]->id;
 $MC=$condvTPT[0]->is_cond;
}
		$SQLcondv = "SELECT * FROM ".$table_meta_conditions." WHERE id='".$mc_ID."'";
		$condTPT = $wpdb->get_results($SQLcondv);
		$mctitle=$condTPT[0]->mc_title;
		$mcid=$condTPT[0]->id;
		$metaid=$condTPT[0]->meta_id;
		$cwordid=$condTPT[0]->word_id;

		$AllCV = "SELECT * FROM $table_wording_meta WHERE id='".$metaid."'";
		$CVResult = $wpdb->get_results($AllCV);
		$cmetaname=$CVResult[0]->title;
		$cmetaid=$CVResult[0]->id;
?>
<form style="display:block;" id="newform7" action="" method="POST" enctype="multipart/form-data">
<h2>Conditional Meta Value Settings</h2>
<h2><?php echo $title?$title.' Conditional Value':"Add New Conditional Value";?></h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="MCVid" id="MCVid" value="<?php echo $MCVid; ?>">
<input type="hidden" name="location" id="location" value="">
<p id="designation" style=" border:0px solid gray;">
<label>Meta Title:</label>
<?php 
    echo '<input type="hidden" value="'.$cwordid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input type="hidden" value="'.$cmetaid.'" id="metaid" name="metaid" class="metaid">';
	echo '<input readonly type="text" value="'.$cmetaname.'" id="metaname" name="metadname" class="metadname">';
?>
</p>
<p id="designation" style=" border:0px solid gray;">
<label>Condition Title:</label>
<?php 
	echo '<input type="hidden" value="'.$mcid.'" id="condid" name="condid" class="condid">';
	echo '<input readonly type="text" value="'.$mctitle.'" id="condname" name="condname" class="condname">';
?>
</p>
<p><label>Condition Meta Title</label><input type="text" name="cvtitle" id="cvtitle" value="<?php echo $MCVtitle?$MCVtitle:'';?>"></p>
<p><label>Is Conditions?</label>
<select name="iscmetac" id="iscmetac" onchange="cmcChange(this.value)">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($MC=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($MC=='No')?'selected':''; ?>>No</option>
</select>
</p>
<?php 
if($MC==""){
$displayc='none';
    }
if($MC=="Yes"){
$displayc='none';
    }    
if($MC=="No"){
$displayc='block';
    }     
?>
<p id="iscmetacv" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Condition Meta Value</label><input type="text" name="cvalue" id="cvalue" value="<?php echo $condvTPT[0]->mc_value?$condvTPT[0]->mc_value:'';?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return condvalueinsert('<?php echo $mc_ID;?>','<?php echo plugins_url('ajaxfiles/save_condition_value.php' ,dirname(__FILE__));?>','meta_conditions_values','<?php echo $formtype; ?>');"  name="<?php echo "cvsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
