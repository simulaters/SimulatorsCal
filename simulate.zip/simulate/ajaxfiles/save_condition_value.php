<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
/***************************Condition Meta Start Here****************************/
if($_POST["stats"]=="conditionvaluenew" || $_POST["stats"]=="conditionvalueedit")
{
		$current_date = date("Y-m-d H:i:s");
		$MCVid=$_POST['MCVid'];
		$table = $wpdb->prefix.$_POST['table_name'];
		//$cvalues=$_POST['cvalue']?$_POST['cvalue']:'';
if($_POST['iscmetac']=="Yes"){
$cvalues='';
$iscmetac=$_POST['iscmetac'];
}else{
$cvalues=$_POST['cvalue'];
$iscmetac=$_POST['iscmetac'];	
}
		function rspecial($string,$rp = '') {
		$string = str_replace(' ', ',', $string);
		return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
		}
		$cvalue=rspecial($cvalues,'.'); //  output: _index_id_666
		if(!empty($MCVid)){
		$SQLup = "UPDATE ".$table." SET meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',cond_id='".$_POST['condid']."',mc_title='".html_entity_decode($_POST['cvtitle'])."',mc_value='".$cvalue."',is_cond ='".$iscmetac."' WHERE id='".$MCVid."'";
		$result=$wpdb->query($SQLup);
		$errmsg="Updating";
		}else{
		$data=array('meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'cond_id'=>$_POST['condid'],'mc_title' =>html_entity_decode($_POST['cvtitle']),'mc_value' =>$cvalue,'is_cond' =>$iscmetac);
		$result=$wpdb->insert( $table, $data);
		//$lastid = $wpdb->insert_id;
		$errmsg="Inserting";
		}
}

if($_POST["stats"]=="deleteconditionsvalue")
{
global $wpdb;
$cvid=$_POST['cvid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE FROM ".$table."  WHERE id  ='".$cvid."'";
$result=$wpdb->query($SQLwm);
}
if($result){
echo getallcondvalues($_POST['condid']);
}
	

/***************************Condition title Ed here****************************/