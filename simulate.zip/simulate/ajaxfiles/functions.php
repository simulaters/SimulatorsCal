<?php 
global $wpdb;
$adminurl = admin_url();
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
$table_category = $wpdb->prefix . "categories";
$table_subcategory= $wpdb->prefix . "subcategory";
$table_desig = $wpdb->prefix . "designations";
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";

$currentuserid=get_current_user_id();

function get_designationfiles($DESIGID){
	global $wpdb;
	?>
<table id="wordingsection<?php echo $DESIGID; ?>" class="wp-list-table widefat fixed striped cats">
		<?php $Allwm = "SELECT * FROM wp_wording WHERE desg_id='".$DESIGID."'";
		$dwResult= $wpdb->get_results($Allwm);
		if(count($dwResult)>0){
		?>
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Wording Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Meta?</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Value</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>
		</thead>
		<tbody id="the-list" data-wp-lists="list:cat">

		<?php 
		foreach($dwResult as $allwm){
		$cid=$allwm->id;
		$desg_id=$allwm->desg_id;
		$is_meta=$allwm->is_meta;
		$otherparts=$allwm->otherparts;
		?>
		<tr class="fnl_td" id="wordid<?php echo $cid;?>">		
		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong>
		</td>	

		<td class="description column-description" data-colname="Description"><?php echo $allwm->is_meta;?></td>
		<?php if($is_meta=="No" && $otherparts=="Yes"){?>
		<td class="description column-description" data-colname="Description"><?php echo $allwm->word_value;?></td>
		<?php }else{ ?>		
		<td class="description column-description" data-colname="Description"><?php echo '--';//$allwm->word_value;?></td>
		<?php }?>
		<td class="description column-description" data-colname="Description">
		<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button" onclick="editwording('Update','<?php echo plugins_url('ajaxfiles/editwording.php' ,dirname(__FILE__));?>','<?php echo $cid ;?>','<?php echo $desg_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
		</span>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png"  role="button" onclick="delete_word('wording','<?php echo plugins_url('ajaxfiles/save_wording.php' ,dirname(__FILE__));?>','<?php echo $cid ;?>','deletewording','<?php echo $desg_id ;?>');" 
		class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php if(($is_meta=="Yes")){?>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png"  role="button" 
		onclick="add_wordmeta('Submit','<?php echo plugins_url('ajaxfiles/wording_meta.php' ,dirname(__FILE__));?>','','<?php echo $cid ;?>')"
		class="delete-cat aria-button-if-js" aria-label="Delete “a”"></span>
		<?php } ?>
		</td></tr>	
<?php if(($is_meta=="Yes"))
    {?>		
		<tr class="additionaltab" style="display:block;" id="wordlist<?php echo $cid; ?>">
		<td id="metasection">
<?php echo getmetadata($cid);?>
		</td></tr>
	
		<?php }
		}
		}
else{ ?>
<tr id="cat-2">			
<td class="description column-description">
<span class="ascreen-reader-text">No Record found!</span></td>
</tr>	
<?php } ?>		
</table>
<?php }
/*************************************GET WORDING DATA WITH HTML FORMAT************************************************/
function getmetadata($cid){
	global $wpdb;
?>
<table class="additionaltab2" id="a1wordingmetaid<?php echo $cid; ?>" class="wp-list-table widefat fixed striped cats">
		<?php 
		$Allwm = "SELECT * FROM wp_wording_meta WHERE word_id='".$cid."'";
		$wmResult = $wpdb->get_results($Allwm);
if(count($wmResult)>0){ ?>
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Meta Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Conditions?</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Value</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>	</thead>

		<tbody id="the-list" data-wp-lists="list:cat">
		<?php 

foreach($wmResult as $allwm){
		$mid=$allwm->id;
		$word_id=$allwm->word_id;
		?>
		<tr class="tb_action" id="metasection<?php echo $mid; ?>">		

		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong>
		</td>	
		<td class="description column-description" data-colname="Description"><?php echo $allwm->is_cond;?></td>
		<td class="description column-description" data-colname="Description"><?php echo ($allwm->is_cond=="No")?$allwm->value:'--';?></td>
		<td class="description column-description" data-colname="Description">
		<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button" onclick="editmeta('Update','<?php echo plugins_url('ajaxfiles/wording_meta.php' ,dirname(__FILE__));?>','<?php echo $mid ;?>','<?php echo $word_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
		</span>
		
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png" role="button" onclick="return delete_wordmetadata('wording_meta','<?php echo plugins_url('ajaxfiles/save_word_meta.php' ,dirname(__FILE__));?>','<?php echo $mid;?>','deletewordingmetadata','<?php echo $word_id;?>');" 
		href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		
		<?php if(($allwm->is_cond=="Yes")){?>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png"  role="button" 
		onclick="add_metacondtitle('Submit','<?php echo plugins_url('ajaxfiles/meta_condition.php' ,dirname(__FILE__));?>','','<?php echo $mid ;?>')"
		class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php } ?>
		</td>
		</tr>		
		<?php if(($allwm->is_cond=="Yes")){?>
		<tr>
		<td colspan="5">
		<?php echo getallcondtitle($mid);?>
		</td>
		</tr>
		<?php } ?>
		<?php 

		}
		?>
		</tbody>
		<?php
	}
	else
	{ ?>
		<tr id="cat-2">			
		<td class="description column-description">
		<span class="ascreen-reader-text">No Record found!</span></td>
		</tr>	
<?php } ?>			
	</table>
	<?php }
	
/*************************************GET META CONDITION DATA WITH HTML FORMAT************************************************/
function  getallcondtitle($mid){
		global $wpdb;
	?>
<table class="additionaltab2" id="metacondtitles<?php echo $mid; ?>" class="wp-list-table widefat fixed striped cats">
		<?php
		$SQLcond = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$mid."'";
		$condTPT = $wpdb->get_results($SQLcond);
		if(count($condTPT)>0){ ?>
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Condition Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Condition?</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>	</thead>
		<tbody>
		<?php 
		foreach($condTPT as $allwm){
		$mcid=$allwm->id;
		$meta_id=$allwm->meta_id;
		$mc_title=$allwm->mc_title;
		?>
		<tr class="meta_condtitle" id="cat-2">		
		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->mc_title;?></a></strong>
		</td>	
		<td class="description column-description" data-colname="Description"><?php echo $allwm->is_cond;?></td>
		<td class="description column-description" data-colname="Description">
		<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button"	onclick="edit_metacond('Update','<?php echo plugins_url('ajaxfiles/meta_condition.php' ,dirname(__FILE__));?>','<?php echo $mcid ;?>','<?php echo $meta_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
     	</span>
		<span class="delete">
			<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png" 
		role="button" onclick="return delete_conditiontitle('meta_conditions','<?php echo plugins_url('ajaxfiles/save_condition.php' ,dirname(__FILE__));?>','<?php echo $mcid;?>','cinditiotitledelete','<?php echo $meta_id;?>');" 
		href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php if(($allwm->is_cond=="Yes")){?>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png"  role="button" 
		onclick="add_condvalues('Submit','<?php echo plugins_url('ajaxfiles/condition_value.php' ,dirname(__FILE__));?>','','<?php echo $mcid ;?>')"
		class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php } ?>
		</td>
		</tr>
		<?php if(($allwm->is_cond=="Yes")){?>
		<tr>
		<td>
		<?php echo getallcondvalues($mcid);?>
		</td>
		<?php } ?>
		
		<?php 

		}
		echo '</tbody>';
		}else{ ?>
				<tr id="cat-2">			
				<td class="description column-description">
				<span class="ascreen-reader-text">No Record found!</span></td>
				</tr>	
		<?php } ?>	
</table>
<?php } 

function getallcondvalues($mcid){
global $wpdb;
?>
<table class="additionaltab2 new_tbls" id="metacondvalues<?php echo $mcid; ?>" class="wp-list-table widefat fixed striped cats">
	<?php
$SQLcondv = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$mcid."'";
$condvTPT = $wpdb->get_results($SQLcondv);
if(count($condvTPT)>0){ ?>
			<thead>
			<tr>
			<th scope="col" class="manage-column column-description sortable desc">
			<a href="#"><span>Title</span></a></th>
			<th scope="col" class="manage-column column-description sortable desc">
			<a href="#"><span>Value</span></a></th>
			<th scope="col" class="manage-column column-description sortable desc">
			<a href="#"><span>Is Conditions?</span></a></th>
			<th scope="col" class="manage-column column-description sortable desc">
			<a href="#"><span>Action</span></span></a>
			</th>
			</tr>
			</thead>
			<tbody id="the-list" data-wp-lists="list:cat">
			<?php 
			foreach($condvTPT as $allwm){
			$cid=$allwm->id;
			$cond_id=$allwm->cond_id;
			$iscond=$allwm->is_cond;
			?>
			<tr id="cat-<?php echo $cid;?>">				
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->mc_title;?></a></strong>
			</td>	
			<td class="description column-description" data-colname="Description"><?php echo ($iscond=="No")?$allwm->mc_value:'--';?></td>
			<td><?php echo $iscond?></td>
			<td class="description column-description" data-colname="Description">
			<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button"	onclick="edit_condvalue('Update','<?php echo plugins_url('ajaxfiles/condition_value.php' ,dirname(__FILE__));?>','<?php echo $cid ;?>','<?php echo $cond_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
     	</span>
		<span class="delete">
<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png" 
		role="button" onclick="return delete_condvalues('meta_conditions_values','<?php echo plugins_url('ajaxfiles/save_condition_value.php' ,dirname(__FILE__));?>','<?php echo $cid;?>','deleteconditionsvalue','<?php echo $cond_id;?>');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”"></span>
			
			<?php if(($allwm->is_cond=="Yes")){?>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png"  role="button" 
		onclick="add_condmetacondtitle('Submit','<?php echo plugins_url('ajaxfiles/cond_meta_cond.php' ,dirname(__FILE__));?>','','<?php echo $cid ;?>')"
		class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php } ?>
		</td>
		</tr>
		<?php if(($allwm->is_cond=="Yes")){?>
		<tr id="cmcid<?php echo $cid;?>">
		<td colspan="5">
		<?php echo cmctitle($cid);?>
		</td>
		</tr>
		<?php } 
}
}else{
			?>
			<tr id="cat-2">			
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			</tr>	
			<?php } ?>			
			</tbody>
</table>
<?php 
}
function cmctitle($mcid){ 
global $wpdb;
?>
<table class="additionaltab2 " id="condmetacondtitles<?php echo $mcid; ?>" class="wp-list-table widefat fixed striped cats">
		<?php
		$SQLcond = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$mcid."'";
		$condTPT = $wpdb->get_results($SQLcond);
		if(count($condTPT)>0){ ?>
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Condition Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Condition?</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>	</thead>
		<tbody>
		<?php 
		foreach($condTPT as $allwm){
		$cmcid=$allwm->id;
		$cmcond_id=$allwm->cmcond_id;
		$mc_title=$allwm->mc_title;
		?>
		<tr class="meta_condtitle" id="cat-<?php echo $cmcid;?>">		
		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->cmc_title;?></a></strong>
		</td>	
		<td class="description column-description" data-colname="Description"><?php echo $allwm->is_cond;?></td>
		<td class="description column-description" data-colname="Description">
		<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button"	onclick="edit_condmetacond('Update','<?php echo plugins_url('ajaxfiles/cond_meta_cond.php' ,dirname(__FILE__));?>','<?php echo $cmcid ;?>','<?php echo $cmcond_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
     	</span>
		<span class="delete">
			<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png" 
		role="button" onclick="return delete_cmctitle('cond_meta_cond','<?php echo plugins_url('ajaxfiles/save_condmetacond_title.php' ,dirname(__FILE__));?>','<?php echo $cmcid;?>','cinditiotitledelete','<?php echo $cmcond_id;?>');" 
		href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php if(($allwm->is_cond=="Yes")){?>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png"  role="button" 
		onclick="add_cmcvalue('Submit','<?php echo plugins_url('ajaxfiles/cond_meta_cond_value.php' ,dirname(__FILE__));?>','','<?php echo $cmcid ;?>')"
		class="delete-cat aria-button-if-js" aria-label="Delete “a”">
		</span>
		<?php } ?>
		</td>
		</tr>
		<?php if(($allwm->is_cond=="Yes")){?>
		<tr id="cmcid<?php echo $cmcid;?>">
		<td colspan="5">
		<?php 
		//echo 'Save Data';
		echo getcmcvalue($cmcid);?>
		</td>
		</tr>
		<?php } ?>
		
		<?php 

		}
		echo '</tbody>';
		}else{ ?>
				<tr id="cat-2">			
				<td class="description column-description">
				<span class="ascreen-reader-text">No Record found!</span></td>
				</tr>	
		<?php } ?>	
</table>
<?php 
}
function getcmcvalue($cmcid){
global $wpdb;
?>
<table class="additionaltab2" id="condmetacondvalues<?php echo $cmcid; ?>" class="condmetacondvalues wp-list-table widefat fixed striped cats">
<?php
$SQLcondv = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$cmcid."'";
$condvTPT = $wpdb->get_results($SQLcondv);
if(count($condvTPT)>0){ ?>
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Value</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>
		</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php 
		foreach($condvTPT as $allwm){
		$cmcvid=$allwm->id;
		$cond_id=$allwm->cmcond_id;
		//$iscond=$allwm->is_cond;
		?>
		<tr id="cat-<?php echo $cmcvid;?>">				
		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->cmcv_title;?></a></strong>
		</td>	
		<td class="description column-description" data-colname="Description"><?php echo $allwm->cmcv_value;?></td>
		<td class="description column-description" data-colname="Description">
		<span class="edit">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/edit.png" role="button"	onclick="edit_cmcvalue('Update','<?php echo plugins_url('ajaxfiles/cond_meta_cond_value.php' ,dirname(__FILE__));?>','<?php echo $cmcvid ;?>','<?php echo $cond_id ;?>')"  class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
		</span>
		<span class="delete">
		<img id="wordicon" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/delete.png" 
		role="button" onclick="return delete_cmcvalue('cond_meta_cond_values','<?php echo plugins_url('ajaxfiles/save_condmetacond_value.php' ,dirname(__FILE__));?>','<?php echo $cmcvid;?>','deletecondmetacondvalue','<?php echo $cond_id;?>');" 
		href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”"></span>
		</td>
		</tr>
		<?php } ?>
	</tbody>
		<?php }else{ ?>
		<tr id="cat-2">			
		<td class="description column-description">
		<span class="ascreen-reader-text">No Record found!</span></td>
		</tr>	

<?php } 
echo '</table>';
}
?>
