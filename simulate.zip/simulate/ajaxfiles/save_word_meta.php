<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
if($_POST["stats"]=="wordmetaupdate" || $_POST["stats"]=="wordmetanew"){
$current_date = date("Y-m-d H:i:s");
$wmeditid=$_POST['wmeditid'];
$table = $wpdb->prefix.$_POST['table_name'];
$wmvalue=($_POST['iscond']=="No")?$_POST['wmvalue']:'';
if(!empty($wmeditid)){
	$SQLup = "UPDATE ".$table_wording_meta." SET word_id='".$_POST['wordid']."',title='".$_POST['wmtitle']."',value='".$wmvalue."',is_cond ='".$_POST['iscond']."' WHERE id='".$wmeditid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{
$data=array('word_id' =>$_POST['wordid'],'title' =>$_POST['wmtitle'],'value' =>$wmvalue,'is_cond' =>$_POST['iscond']);
$result=$wpdb->insert( $table_wording_meta, $data);
//$lastid = $wpdb->insert_id;
$errmsg="Inserting";
}
}
if($_POST["stats"]=="deletewordingmetadata"){
global $wpdb;
$mid=$_POST['mid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b,c FROM ".$table." a
LEFT JOIN wp_meta_conditions b ON ( a.id = b.meta_id)
LEFT JOIN wp_meta_conditions_values c ON ( b.id = c.cond_id)
WHERE a.id  ='".$mid."'";
$result=$wpdb->query($SQLwm);
}
if($result){
echo getmetadata($_POST['wordid']);
} ?>