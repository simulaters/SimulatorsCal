<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";
$table_neta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
$metaid=$_POST['meta_ID'];
$wmc_ID=$_POST['mc_ID'];
$buttontext = $_POST['sbmt'];
$formtype = $_POST['wordtype'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if(!empty($wmc_ID)){
$SQLcondS = "SELECT * FROM ".$table_meta_conditions." WHERE meta_id='".$metaid."' AND id='".$wmc_ID."'";
$condTPTS = $wpdb->get_results($SQLcondS);
$condtitle=$condTPTS[0]->mc_title?$condTPTS[0]->mc_title:'';
$condid=$condTPTS[0]->id;		
}
$SQLwmcond = "SELECT * FROM ".$table_wording_meta." WHERE id='".$metaid."'";
$wmcondTPT = $wpdb->get_results($SQLwmcond);
$subtitlem=$wmcondTPT[0]->title?$wmcondTPT[0]->title:'';
$wmTPTid=$wmcondTPT[0]->id;
$mwTPTid=$wmcondTPT[0]->word_id;

?>

<form style="display:block;" id="newform6" action="" method="POST" enctype="multipart/form-data">
<h2><?php echo $title?$title.' Meta Conditions':"Add New Meta Conditions";?>  </h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="wmcid" id="wmcid" value="<?php echo $wmc_ID; ?>">
<input type="hidden" name="location" id="location" value="">
<p id="designation" style=" border:0px solid gray;">
<label>Wording Meta Title</label>
<?php 
	echo '<input type="hidden" value="'.$mwTPTid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input type="hidden" value="'.$wmTPTid.'" id="metaid" name="metaid" class="metaid">';
	echo '<input readonly type="text" value="'.$subtitlem.'" id="metatitle" name="metatitle" class="metatitle">';
?>
</p>
<p><label>Condition Title</label><input type="text" name="mctitle" id="mctitle" value="<?php echo $condtitle?$condtitle:'';?>"></p>
<p><label>Is Condition Meta?: </label>
<select name="iscmeta" id="iscmeta" onchange="leaveChange(this.value)">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($condTPTS[0]->is_cond=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($condTPTS[0]->is_cond=='No')?'selected':''; ?>>No</option>
</select>
</p>
<?php $dislay=($condTPTS[0]->is_cond=='No')?'block':'none'; ?>
<p id="iscmetaop" style="display:<?php echo $dislay ;?>;"><label>Other Parts?: </label>
<select name="otherparts" id="otherparts" onchange="leaveChange1(this.value)">
<option value="">Select Value</option>
<option value="No" <?php echo ($condTPTS[0]->otherparts=='No')?'selected':''; ?>>No</option>
<option value="Yes" <?php echo ($condTPTS[0]->otherparts=='Yes')?'selected':''; ?>>Yes</option>
</select>
</p>
<?php $dislays2=($condTPTS[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop2" style="display:<?php echo $dislays2?:'none';?>;"><label>Optional Types?: </label>
<select name="optypes" id="optypes" onchange="leaveChange6(this.value)">
<option value="">Select Value</option>
<option value="Add" <?php echo ($condTPTS[0]->optypes=='Add')?'selected':''; ?>>Add</option>
<option value="Sub" <?php echo ($condTPTS[0]->optypes=='Sub')?'selected':''; ?>>Sub</option>
<option value="Mult" <?php echo ($condTPTS[0]->optypes=='Mult')?'selected':''; ?>>Mult</option>
<option value="Div" <?php echo ($condTPTS[0]->optypes=='Div')?'selected':''; ?>>Div</option>
</select>
</p>
<?php $displayc=($condTPTS[0]->otherparts=="Yes")?'block':'none';?>
<p id="iscmetaop1" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Condition Value</label><input type="text" name="wmcvalue" id="wmcvalue" value="<?php echo $condTPTS[0]->mc_value; ?>"></p>

<p><label></label><input type="button" class="btn btn-info" onclick="return insertcondinserttitle('<?php echo $metaid;?>','<?php echo plugins_url('ajaxfiles/save_condition.php' ,dirname(__FILE__));?>','meta_conditions','<?php echo $formtype; ?>');"  name="<?php echo "mcsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>