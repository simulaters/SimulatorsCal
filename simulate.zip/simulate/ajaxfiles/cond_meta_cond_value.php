<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$cond_meta_cond_value=$wpdb->prefix."cond_meta_cond_values";
$cond_meta_cond=$wpdb->prefix."cond_meta_cond";
$table_meta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
$cmc_ID=$_POST['cmc_id'];
$cmcv_ID=$_POST['cmcv_ID'];
$buttontext = $_POST['sbmt'];
$formtype = $_POST['wordtype'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if(!empty($cmcv_ID)){
$SQLcondv = "SELECT * FROM ".$cond_meta_cond_value." WHERE cmcond_id='".$cmc_ID."' AND id='".$cmcv_ID."'";
$condvTPT = $wpdb->get_results($SQLcondv);
$CMCVtitle=$condvTPT[0]->cmcv_title;
$CMCVid=$condvTPT[0]->id;
}
		$SQLcondv = "SELECT * FROM ".$cond_meta_cond." WHERE id='".$cmc_ID."'";
		$condTPT = $wpdb->get_results($SQLcondv);
		
		$mctitle=$condTPT[0]->cmc_title;
		$cwordid=$condTPT[0]->word_id;
		$metaid=$condTPT[0]->meta_id;		
        $subcondid=$condTPT[0]->subconds_id;	
        $cmcid=$condTPT[0]->id;
        $cmcondid=$condTPT[0]->cmcond_id;
        
        
		$SQLwmcond = "SELECT * FROM ".$table_meta_conditionsvalue." WHERE id='".$cmcondid."'";
		$CVResult = $wpdb->get_results($SQLwmcond);
		//print_r($CVResult);
		$metaname=$CVResult[0]->mc_title;
		$metacid=$CVResult[0]->id;
?>
<form style="display:block;" id="newform9" action="" method="POST" enctype="multipart/form-data">
<h2>Conditional Meta Conditional Value Settings</h2>
<h2><?php echo $title?$title.' Conditional meta condition Value':"Add New Conditional Value";?></h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="CMCVid" id="CMCVid" value="<?php echo $CMCVid; ?>">
<p id="designation" style=" border:0px solid gray;">
<label>Conditional Meta Title:</label>
<?php 
echo '<input type="hidden" value="'.$cwordid.'" id="wordid" name="wordid" class="wordid">';
echo '<input type="hidden" value="'.$metaid.'" id="metaid" name="metaid" class="metaid">';
echo '<input type="hidden" value="'.$subcondid.'" id="subcondid" name="subcondid" class="subcondid">';
echo '<input type="hidden" value="'.$metacid.'" id="metacid" name="metacid" class="metacid">';
echo '<input readonly type="text" value="'.$metaname.'" id="metaname" name="metadname" class="metadname">';
?>
</p>
<p id="designation" style=" border:0px solid gray;">
<label>Condition Title:</label>
<?php 
	echo '<input type="hidden" value="'.$cmcid.'" id="cmcid" name="cmcid" class="cmcid">';
	echo '<input readonly type="text" value="'.$mctitle.'" id="condname" name="condname" class="condname">';
?>
</p>
<p><label>Condition Meta Title</label><input type="text" name="cmcvtitle" id="cmcvtitle" value="<?php echo $CMCVtitle?$CMCVtitle:'';?>"></p>
<p id="iscmetacv"><label>Condition Meta Value</label><input type="text" name="cmcvalue" id="cmcvalue" value="<?php echo $condvTPT[0]->cmcv_value?$condvTPT[0]->cmcv_value:'';?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return cmcvalueinsert('<?php echo $cmc_ID;?>','<?php echo plugins_url('ajaxfiles/save_condmetacond_value.php' ,dirname(__FILE__));?>','cond_meta_cond_values','<?php echo $formtype; ?>');"  name="<?php echo "cvsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
