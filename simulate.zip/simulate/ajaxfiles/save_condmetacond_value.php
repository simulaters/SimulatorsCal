<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
/***************************Condition Meta Start Here****************************/
if($_POST["stats"]=="cmetacvaluenew" || $_POST["stats"]=="cmetacvalueedit")
{
		
		//print_r($_POST);
		$current_date = date("Y-m-d H:i:s");
		$CMCVid=$_POST['CMCVid'];
		$table = $wpdb->prefix.$_POST['table_name'];
		$cmcvalues=$_POST['cmcvalue']?$_POST['cmcvalue']:'';
    	function rspecial($string,$rp = '') {
		$string = str_replace(' ', ',', $string);
		return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
		}
		$cmcvalue=rspecial($cmcvalues,'.'); //  output: _index_id_666
		if(!empty($CMCVid)){
		$SQLup = "UPDATE ".$table." SET meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',subconds_id='".$_POST['subcondid']."',cond_id='".$_POST['metacid']."',cmcond_id='".$_POST['cmcid']."',cmcv_title='".html_entity_decode($_POST['cmcvtitle'])."',cmcv_value='".$cmcvalue."' WHERE id='".$CMCVid."'";
		$result=$wpdb->query($SQLup);
		}else{
		$data=array('meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'subconds_id'=>$_POST['subcondid'],'cond_id'=>$_POST['metacid'],'cmcond_id'=>$_POST['cmcid'],'cmcv_title' =>html_entity_decode($_POST['cmcvtitle']),'cmcv_value' =>$cmcvalue);
		$result=$wpdb->insert( $table, $data);
		}
}

if($_POST["stats"]=="deletecondmetacondvalue")
{
global $wpdb;
$cmcvid=$_POST['cmcvid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE FROM ".$table."  WHERE id  ='".$cmcvid."'";
$result=$wpdb->query($SQLwm);
}
if($result){
echo getcmcvalue($_POST['cmcid']);
}
	

/***************************Condition title Ed here****************************/