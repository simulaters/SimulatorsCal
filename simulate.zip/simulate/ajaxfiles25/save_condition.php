<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
/***************************Condition Title Start Here****************************/
if($_POST["stats"]=="metacinditionnew" || $_POST["stats"]=="metacinditionupdate"){
$current_date = date("Y-m-d H:i:s");
$wmcid=$_POST['wmcid'];
$table = $wpdb->prefix.$_POST['table_name'];
if($_POST['iscmeta']=="Yes"){
$wmvalue='';
$oparts='No';
$otypes='Mult';
$iscmeta=$_POST['iscmeta'];
}
if($_POST['iscmeta']=="No" && $_POST['otherparts']=="No")
{
$iscmeta=$_POST['iscmeta'];	
$oparts=$_POST['otherparts']?$_POST['otherparts']:'';
$otypes='Mult';
$wmvalue='';
}
if($_POST['iscmeta']=="No" && $_POST['otherparts']=="Yes")
{
$iscmeta=$_POST['iscmeta'];
$wmvalue=$_POST['wmcvalue']?$_POST['wmcvalue']:'';
$oparts=$_POST['otherparts']?$_POST['otherparts']:'';
$otypes=$_POST['optypes']?$_POST['optypes']:'';
}
if(!empty($wmcid)){
$SQLup = "UPDATE ".$table." SET meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',mc_title='".$_POST['mctitle']."',mc_value='".$wmvalue."', 
is_cond ='".$iscmeta."',otherparts ='".$oparts."',optypes ='".$otypes."' WHERE id='".$wmcid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{
$data=array('meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'mc_title' =>$_POST['mctitle'],'mc_value' =>$wmvalue,
'is_cond' =>$iscmeta,'otherparts' =>$oparts,'optypes' =>$otypes);
$result=$wpdb->insert( $table, $data);
//$lastid = $wpdb->insert_id;
$errmsg="Inserting";
}}
if($_POST["stats"]=="cinditiotitledelete"){
	global $wpdb;
$cid=$_POST['cid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b FROM ".$table."  a 
LEFT JOIN wp_meta_conditions_values b ON ( a.id = b.cond_id)
LEFT JOIN wp_cond_meta_cond e ON ( b.id = e.cmcond_id)
LEFT JOIN wp_cond_meta_cond_values f ON ( e.id = f.cmcond_id)

WHERE a.id  ='".$cid."'";
$result=$wpdb->query($SQLwm);
}
if($result){
echo getallcondtitle($_POST['metaid']);
}
	

/***************************Condition title Ed here****************************/