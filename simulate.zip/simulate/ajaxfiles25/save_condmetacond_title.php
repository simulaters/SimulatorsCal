<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
/***************************Condition Title Start Here****************************/
if($_POST["stats"]=="mcmnew" || $_POST["stats"]=="mcmedit"){
$current_date = date("Y-m-d H:i:s");
$cmcid=$_POST['cmcid'];
$table = $wpdb->prefix.$_POST['table_name'];
if($_POST['iscmetac']=="Yes"){
$cmcvalue='';
$oparts='No';
$otypes='Mult';
$iscmetac=$_POST['iscmetac'];
}
if($_POST['iscmetac']=="No" && $_POST['cmcotherparts']=="No")
{
$iscmetac=$_POST['iscmetac'];	
$oparts=$_POST['cmcotherparts']?$_POST['cmcotherparts']:'';
$otypes='Mult';
$cmcvalue='';
}
if($_POST['iscmetac']=="No" && $_POST['cmcotherparts']=="Yes")
{
$iscmetac=$_POST['iscmetac'];
$cmcvalue=$_POST['cmcvalue']?$_POST['cmcvalue']:'';
$oparts=$_POST['cmcotherparts']?$_POST['cmcotherparts']:'';
$otypes=$_POST['optypes']?$_POST['optypes']:'';
}
if(!empty($cmcid)){
$SQLup = "UPDATE ".$table." SET cmcond_id='".$_POST['cmetacid']."',meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',cmc_title='".$_POST['cmctitle']."',cmc_value='".$cmcvalue."', 
is_cond ='".$iscmetac."',otherparts ='".$oparts."',optypes ='".$otypes."' WHERE id='".$cmcid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{
$data=array('cmcond_id'=>$_POST['cmetacid'],'meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'cmc_title' =>$_POST['cmctitle'],'cmc_value' =>$cmcvalue,
'is_cond' =>$iscmetac,'otherparts' =>$oparts,'optypes' =>$otypes);
$result=$wpdb->insert( $table, $data);
//$lastid = $wpdb->insert_id;
$errmsg="Inserting";
}}

if($_POST["stats"]=="cinditiotitledelete"){
	global $wpdb;
$cmcid=$_POST['cmcid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE  FROM ".$table."   WHERE id ='".$cmcid."'";
$result=$wpdb->query($SQLwm);
}
if($result){
echo cmctitle($_POST['cmetacid']);
}
	

/***************************Condition title Ed here****************************/