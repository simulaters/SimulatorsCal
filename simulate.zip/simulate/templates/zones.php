<?php 
global $wpdb;
@session_start(); 
$adminurl = admin_url();
//$id="";
$siteurl = get_option("siteurl");
$tablename= $wpdb->prefix . "zone";
$current_date = date("Y-m-d H:i:s");
 //===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;
$SQLcat = "SELECT * FROM $tablename";
$allCategoriesc = $wpdb->get_results($SQLcat);
$total = count($allCategoriesc);
$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$allZones = $wpdb->get_results($SQLcatp);   
$zoneids=$_GET['z_ID'];
if($_GET['action']=="editzone"){
		$title="Edit Zone";
		$buttontext="Update";
		$aurl=$adminurl."admin.php?page=zone";
		$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Add New Zone</a>';
		$SQLecat = "SELECT * FROM $tablename WHERE id  LIKE '%".$zoneids."%'";
		$edCat = $wpdb->get_results($SQLecat);
		 $id=$edCat[0]->id;
		if(isset($_POST['Update'])){
					$zname=$_POST['zname'];
					$zdepartment=$_POST['zdepartment'];
					$zdescription=$_POST['zdescription'];
					$zdcode=$_POST['zdcode'];				
				 $SQLup = "UPDATE ".$tablename." SET dcode='".$zdcode."',description='".$zdescription."',department='".$zdepartment."',zone='".$zname."',modify='".$current_date."' WHERE id='".$id."'";
				$c=$wpdb->query($SQLup);
				if($c){
				$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($adminurl."admin.php?page=zone");	
				exit;
				}
		}
}else if($_GET['action']=="deletezone"){
$SQLD = "DELETE FROM $tablename WHERE id =$zoneids";
$Del=$wpdb->query($SQLD);
if($Del){
$_SESSION['id']="success";
$_SESSION['SuccessMsg']="Record Deleted Successfully";
wp_redirect($adminurl."admin.php?page=zone");	
	exit; 
}else{
$_SESSION['id']="error";
$_SESSION['SuccessMsg']="Record Deleted Error";
}
}else {
if(isset($_POST['Submit'])){
					$zname=$_POST['zname'];
					$zdepartment=$_POST['zdepartment'];
					$zdescription=$_POST['zdescription'];
					$zdcode=$_POST['zdcode'];				
		if(empty($zname)){
$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter zone name.........";		
		}
		else
		{
		global $wpdb;
	$SQL = "SELECT * FROM $tablename WHERE department  LIKE '%".$zdepartment."%'";
	$rsSubject = $wpdb->get_results($SQL);
	if(empty($rsSubject)){	
		$data=array('dcode' => $zdcode,'zone' => $zname, 'department' =>$zdepartment,'description' =>$zdescription,'status' => 'Active','created' => $current_date);
		$insert=$wpdb->insert( $tablename, $data);
$_SESSION['id']="success";
		$_SESSION['SuccessMsg']="Zone added Successfully";
		wp_redirect($adminurl."admin.php?page=zone");	
	exit;
		}else{
			$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Zone already exists....";
		wp_redirect($adminurl."admin.php?page=zone");	
	exit;
		}
	}
}
$title="Add New Zone";
$buttontext="Submit";
}

if(isset($_POST["importSubmit"])){
	global $wpdb;
$brands=	array();
$dataPoints=	array();
$dataPoint=	array();
$filename=$_FILES["file"]["tmp_name"];	
if($_FILES["file"]["size"] > 0)
{
$handle2 = fopen($filename, "r");
while (($data2 = fgetcsv($handle2)) !== FALSE) {
$department=explode(" ",$data2[0],2);
$SQL11="SELECT * FROM $tablename WHERE dcode='".esc_sql($department[0])."'";
$datum11 = $wpdb->get_row($SQL11);
if($datum11 > 0){
	$result='al';
}else{
$data=array('dcode' => $department[0],'zone' => $data2[1], 'department' =>$department[1],'status' => 'Active','created' => $current_date);
$result=$wpdb->insert( $tablename, $data);
}
}
fclose($handle2);
}
if($result){
if($result=="al"){
$_SESSION['id']="success";
$_SESSION['SuccessMsg']= "CSV data already exists";
wp_redirect($adminurl."admin.php?page=zone");	
	exit;
}else{
$_SESSION['id']="success";
$_SESSION['SuccessMsg']= 'CSV data has been inserted successfully.';
wp_redirect($adminurl."admin.php?page=zone");	
	exit;
}}else{
$_SESSION['id']="error";
$_SESSION['SuccessMsg']= 'Error:csv data import Error';
}
}
?>
<script type="text/javascript">
jQuery(document).ready(function(){
    $("#<?php echo $_SESSION['id'];?>").show(1).delay(6000).hide('slow');
	});
</script>

<div id="primary1" class="content-area">
<div id="wrapper">
<div class="panel panel-default">
		<div class="panel-heading">
		Import CSV File
		<button type="button" onclick="return toggleDiv('importFrm');" class="btn btn-info" data-toggle="collapse" data-target="#importFrm">CSV Import</button>
<div class="panel-body collapse" style="display:none;" id="importFrm">
<form action="" method="post" enctype="multipart/form-data" >
<input type="file" name="file" />
<input type="submit" class="btn btn-info" name="importSubmit" value="IMPORT">
</form>
<table class="table table-bordered">
</table>
</div>
</div>
</div>
<div id="col-left">
<div class="form-wrap wrap">
<h2 ><?php echo $title?$title:"";?> <?php echo $addurl; ?></h2>
<?php if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }?>
<form id="addcat" method="post" action="" class="validate">
	<div class="form-field form-required term-name-wrap">
	<label for="zname">Zone Name</label>
	<input name="zname" id="zname" value="<?php echo $edCat[0]->zone?$edCat[0]->zone:''; ?>" size="40" aria-required="true" type="text">
	</div>
	<div class="form-field form-required term-name-wrap">
	<label for="zdepartment">Department</label>
	<input name="zdepartment" id="zdepartment" value="<?php echo $edCat[0]->department?$edCat[0]->department:''; ?>" size="40" aria-required="true" type="text">
	</div>
	<div class="form-field form-required term-name-wrap">
	<label for="zdcode">Dep. Code</label>
	<input name="zdcode" id="zdcode" value="<?php echo $edCat[0]->dcode?$edCat[0]->dcode:''; ?>" size="40" aria-required="true" type="text">
	</div>
	
	<div class="form-field term-description-wrap">
	<label for="cat-description">Description</label>
	<textarea name="zdescription" id="zdescription" rows="5" cols="40"><?php echo $edCat[0]->description?$edCat[0]->description:''; ?></textarea>
	</div>
<p class="submit"><input name="<?php echo $buttontext;?>" id="submit" class="button button-primary" value="<?php echo $buttontext;?>" type="submit"></p>
</form>
</div>
</div><!-- /col-left -->
<div id="col-right">
<div class="col-wrap">
<form id="posts-filter" method="post">
<div class="alignleft actions bulkactions">
</div>
</div>
<h2 class="1screen-reader-text">Zone Lists</h2>
<table class="wp-list-table widefat fixed striped cats">
	<thead>
	<tr>
		<th id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label><span><a href="#">Code</a></span></th><th scope="col" id="name" class="manage-column column-name column-primary sortable desc"><a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th>
		<th scope="col" class="manage-column column-description sortable desc"><a href="#"><span>Department</span><span class="sorting-indicator"></span></a></th>
		<th scope="col" id="description" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a href="#"><span>Status</span><span class="sorting-indicator"></span></a></th>	</tr>
	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($allZones)>0){
			foreach($allZones as $zone){
			$cid=$zone->id;
			?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			<label class="screen-reader-text" for="cb-select-2">Select a</label>
			<?php echo $zone->dcode;?>
						</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $zone->zone;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=zone&action=editzone&z_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span><span class="delete"><a role="button" href="<?php echo $siteurl;?>/wp-admin/admin.php?page=zone&action=deletezone&z_ID=<?php echo $cid; ?>" class="delete-cat aria-button-if-js" aria-label="Delete “a”">Delete</a> | </span></div>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo $zone->department;?></span></td>
			
			
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo $zone->description;?></span></td>
			<td class="posts column-posts" data-colname="Count"><a href="#"><?php echo $zone->status;?></a></td>
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"></a></strong><br>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts" data-colname="Count">
			<a href="#"></a></td>
			</tr>	
			<?php } ?>			
			</tbody>
			<tfoot>
	<tr>
		<th id="cb"  class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2">Select All</label><span><a href="#">Code</a></span></th><th scope="col" class="manage-column column-name column-primary sortable desc"><a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th>
		<th scope="col" class="manage-column column-description sortable desc"><a href="#"><span>Department</span><span class="sorting-indicator"></span></a></th>
		<th scope="col" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-posts num sortable desc"><a href="#"><span>Status</span><span class="sorting-indicator"></span></a></th>	</tr>
	</tfoot>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
</table>
</form>
</div>
</div><!-- /col-right -->
</div>
</div>
</div>
