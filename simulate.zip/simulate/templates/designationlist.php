<?php
global $wpdb;
@session_start(); 
$adminurl = admin_url();
//$id="";
$siteurl = get_option("siteurl");
$table_desig = $wpdb->prefix . "designations";
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";

$items_per_page =50;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;

$aurl=$adminurl."admin.php?page=designation&type=new&action=designation";
$addnewscenariourl='<a class="btnschemea" id="addnewurls" href="'.$aurl.'">Add New Scenario</a>';

$designation=$adminurl."admin.php?page=designation&action=designation";
$deswording=$adminurl."admin.php?page=designation&action=deswording";
$wordmeta=$adminurl."admin.php?page=designation&action=wordmeta";

 if(isset($_REQUEST['des_name'])){
    $des_name=$_REQUEST['des_name'];
	$WHERE = "WHERE des_name LIKE '%".trim($_REQUEST['des_name'])."%' OR number LIKE '%".trim($_REQUEST['des_name'])."%'";
 }
  if(isset($_REQUEST['sector'])){
    $sector=$_REQUEST['sector'];
	$WHERE = "WHERE subcatid LIKE '%".trim($_REQUEST['sector'])."%'";
 }
if(isset($_REQUEST['wdes_name'])){
global $wpdb;
$wdes_name=$_REQUEST['wdes_name'];
$pm=array();
$table_desig = $wpdb->prefix . "designations";
$Alld ="SELECT * FROM wp_wording WHERE title IN ('".esc_sql(trim($_REQUEST['wdes_name']))."') OR desg_id IN (SELECT id FROM wp_designations WHERE number LIKE '%".trim($_REQUEST['wdes_name'])."%') ORDER BY id DESC";
$sectord = $wpdb->get_results($Alld);
//print_r($sectord);
$dids=$sectord[0]->id; 
foreach ( $sectord as $print2 )   {
$pm[]=$print2->id; 
}	
$trafic=implode("','",$pm);
$WHEREs = "WHERE id IN ('".$trafic."')";
}
 

function sectorsname($id){
global $wpdb;
$table_category = $wpdb->prefix . "categories";
$Alld = "SELECT * FROM $table_category WHERE id =".$id." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
$result=$sector[0]->category_name;
return 	$result;
}

function subsectors($ids){
global $wpdb;
$table_subcategory= $wpdb->prefix . "subcategory";
$Alld = "SELECT * FROM $table_subcategory WHERE id =".$ids." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
$result=$sector[0]->category_name;
return 	$result;
}

function get_subsectorslist($ids,$cname){
global $wpdb;
$table_subcategory= $wpdb->prefix . "subcategory";
$Alld = "SELECT * FROM $table_subcategory WHERE catid =".$ids." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
?>
<select name="subsectors<?php echo $ids;?>" id="subsectors<?php echo $ids;?>" onChange="window.location='?page=designation&sector='+this.value" >
<option><?php echo '<b>'.$cname.'</b>';?></option>
<?php 
foreach($sector as $subsectors){
	 if (!empty($_GET['sector']) && $_GET['sector'] == $subsectors->id) {
        $selected = 'selected="selected"';
		$class="active";
    } else {
        $selected = '';
    $class="";
	}
    ?>
<option class="<?php echo $class;?>" <?php echo $selected;?> value="<?php echo $subsectors->id;?>"><?php echo $subsectors->category_name; ?></option>
<?php 
}?>
</select>
<?php 
}

function authorname($atid){	
		$user_info = get_userdata($atid);
		$username = $user_info->user_login;
		$first_name = $user_info->first_name;
		$last_name = $user_info->last_name;
		$authorinfo= $username?$username: $first_name." ".$lirst_name;	
		return 	$authorinfo;
}

function deslist($did){
global $wpdb;
$table_desig = $wpdb->prefix . "designations";
$Alld = "SELECT * FROM $table_desig WHERE id =".$did." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
$result=$sector[0]->des_name;
return 	$result;
	}
	function deslistpdfname($did){
global $wpdb;
$table_desig = $wpdb->prefix . "designations";
$Alld = "SELECT * FROM $table_desig WHERE id =".$did." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
$numbers=    $sector[0]->number;
$resultCS =  basename($numbers, ".pdf");
return 	$resultCS;
	}
function wmlist($wmid){
global $wpdb;
$table_wording = $wpdb->prefix . "wording";
$Alld = "SELECT * FROM $table_wording WHERE id =".$wmid." ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
$result=$sector[0]->title;
return $result;
}
$Alld = "SELECT * FROM $table_desig  ".$WHERE." ORDER BY id DESC
LIMIT ".$offset.",".$items_per_page."";
$alldesignations = $wpdb->get_results($Alld);

$Allw = "SELECT * FROM $table_wording ".$WHEREs." ORDER BY id DESC
LIMIT ".$offset.",".$items_per_page."";
$allwording = $wpdb->get_results($Allw);

//print_r($allwording);

$Allwm = "SELECT * FROM $table_wording_meta ORDER BY id DESC
LIMIT ".$offset.",".$items_per_page."";
$allwordingmeta = $wpdb->get_results($Allwm);
$des_name = isset($_REQUEST['des_name'])?$_REQUEST['des_name']:"";
$wdes_name = isset($_REQUEST['wdes_name'])?$_REQUEST['wdes_name']:"";
?>

<script type="text/javascript">
jQuery(document).ready(function(){
$("#<?php echo $_SESSION['id'];?>").show(1).delay(6000).hide('slow');
$("#resultM").show(1).delay(6000).hide('slow');
});
function delete_destination(tname,url,ids,strs){
	//alert (tname+url+ids+strs);
	var designation_url=document.getElementById('designationredirecturl').value;
//	if(confirm("Do you want to delete?")){
 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"table_name":tname,"did":ids,"stats":strs},
                url: url,
				success: function(datad){
				    //alert (datad);
    			var obj = $.parseJSON( datad );
				if( obj.result === "ok" ){
			$('#resultM').html(obj.msg);
			$('#resultM').show();
			setTimeout(function () {
				window.location.href = designation_url;
				}, 500);
				}else{
				   $('#resultM').html(obj.msg);
				   $('#resultM').show();
				    }
				},
                error: function(){
                 $('#resultM').html(datad);
				 $('#resultM').show();
                }
	           });
//	}

}

function delete_wording(tname,url,ids,strs){
	//alert (tname+url+ids+strs);
		var wordlocation_url=document.getElementById('wordingredirecturl').value;
if(confirm("Do you want to delete?")){
$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"wid":ids,"stats":strs},
		url: url,
		success: function(dataw){
		//alert (dataw);
		var obj = $.parseJSON( dataw );
		if( obj.result === "ok" ){
		$('#resultM').html(obj.msg);
		$('#resultM').show();
			setTimeout(function () {
			window.location.href = wordlocation_url;
			}, 500);
		}else{
		$('#resultM').html(obj.msg);
		$('#resultM').show();
		}
		},
		error: function(){
		$('#resultM').html(dataw);
		$('#resultM').show();
		}
});
}
}


function delete_wordmeta(tname,url,ids,strs){
	var metalocation_url=document.getElementById('metaredirecturl').value;
if(confirm("Do you want to delete?")){
	//alert (tname+url+ids+strs);
 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"table_name":tname,"mid":ids,"stats":strs},
                url: url,
				success: function(datas){
				   // alert (datas);
    			var obj = $.parseJSON( datas );
				if( obj.result === "ok" ){
			$('#resultM').html(obj.msg);
			$('#resultM').show();
				setTimeout(function () {
				window.location.href = metalocation_url;
				}, 500);
				}else{
				   $('#resultM').html(obj.msg);
				   $('#resultM').show();
				    }
				},
                error: function(){
                 $('#resultM').html(datas);
				 $('#resultM').show();
                }
	           });
}
}
function view_all(viewallurl){
window.location.href= viewallurl;	
} 
</script>
<div id="primary" class="content-area">
<div id="wrapper" class="wrap">
<?php if($_GET['action']=="" )
{
if($_GET['page']=="designation" && !isset($_GET['sector'])){
	$pagest=($_GET['page']=="designation");
	$class='active';
	}
else{
$pagest=($_GET['sector']!="");	
$class='';
}
}else{
$pagest=($_GET['action']=="designation");
$class='active';
}
?>
<section id="sellingprice2" class="tabist tabcontent1 ">
<div class="tab">
<ul>
<li><a href="<?php echo $designation;?>" class="tablinks <?php echo $class; ?>">All Scenarios</a></li>
<?php 
global $wpdb;
$table_category = $wpdb->prefix . "categories";
$Alld = "SELECT * FROM $table_category ORDER BY id DESC";
$sector = $wpdb->get_results($Alld);
foreach($sector as $sectrs){
?>
<li class="<?php echo $classt;?>" id="tab<?php echo $sectrs->id;?>">
<?php echo get_subsectorslist($sectrs->id,$sectrs->category_name);?>
</li>
<?php
}
?>
</ul>
</div>
</section>
<?php 
if($pagest){
$Alld = "SELECT * FROM $table_desig  ".$WHERE." ORDER BY id DESC";
$allCategoriesc = $wpdb->get_results($Alld);
$total = count($allCategoriesc);
?>
<section id="projecttypelist" class="tabcontent1">
<div class="col-wrap">
<h3 class="wp-heading-inline">List of Scenarios</h3>
<hr class="wp-header-end">

<form name="frmsearch" id="frmsearch" action="<?php echo add_query_arg( array( 'des_name' => $des_name )) ;?>" method="Post">
<table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
<tr>

<td align="right" style="padding: 10px 2px;" >Search <input type="text" name="des_name" id="des_name" value="<?php echo $des_name;?>" placeholder="Enter Title or pdf name here....">&nbsp;
<input type="submit" class="btnscheme" name="btnsearch" id="btnsearch" value="Search"/>
<input type="button" class="btnscheme" name="btnall" id="btnall" value="View all" onclick="return view_all('<?php echo  $siteurl;?>/wp-admin/admin.php?page=designation');"/> 
<p>Search the Scenario by title or pdf file name (BAR-EN-103)</p>
</td>
<td><?php echo $addnewscenariourl?$addnewscenariourl:''; ?></td>
</tr>
</table>
</form>
</div>

<form id="posts-filter" method="post">
<input type="hidden" name="designationredirecturl" id="designationredirecturl" value="<?php echo $designation;?>">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-name column-primary sortable desc">
<a href="#"><span>Title</span><span class="sorting-indicator"></span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Author</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Sectors</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Sub Sectors</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>PDF Names</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Date</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Action</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($alldesignations)>0){
			foreach($alldesignations as $alldes){
			$catgsid=$alldes->id;
			$author=$alldes->author;
			$catid=$alldes->catid;
			$subcatid=$alldes->subcatid;
			$numbers=$alldes->number;
			$pdfname =  basename($numbers, ".pdf");
$awurl=$adminurl."admin.php?page=designation&action=deswording&type=new&did=$catgsid";
$editwurl='<a class="page-title-action" id="addnewurl" href="'.$awurl.'">Edit Wording</a>';
$senarioeditlink=$adminurl."admin.php?page=designation&action=scenario&type=scenarioslist&des_name=$pdfname";
$addwurl='<a class="page-title-action" id="addnewurl" href="'.$senarioeditlink.'">View Scenario</a>';


			?>
			<tr id="cat-2">			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="<?php echo $adminurl;?>admin.php?page=designation&action=designation&type=edit&d_ID=<?php echo $catgsid; ?>" aria-label="“a” (Edit)"><?php echo $alldes->des_name;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=designation&type=edit&d_ID=<?php echo $catgsid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span>
			<span class="delete">
<a role="button" onclick="return delete_destination('designations','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $catgsid;?>','deleteddesignation');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> | </span></div>
	</td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo authorname($author);?></span></td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo sectorsname($catid);?></span></td>	
			
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo subsectors($subcatid);?></span></td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo deslistpdfname($catgsid);?></span></td>
			<td class="description column-description" data-colname="Description"><?php echo $alldes->created;?></td>
			<td class="description column-description" data-colname="Description"><?php echo $addwurl;?></td>
			<!--<td class="description column-description" data-colname="Description"><?php /*echo $editwurl;*/?></td>-->
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</div>
</section>
<?php } 
//****************************//

if($_GET['action']=="deswording" && $_GET['page']=="designation"){ 
$Alld = "SELECT * FROM $table_wording  ".$WHERE." ORDER BY id DESC";
$wording = $wpdb->get_results($Alld);
$totals = count($wording);
?>
<section id="projecttypelist" class="tabcontent1">
<div class="col-wrap">
<h3 class="wp-heading-inline">Wording data of the Designations</h3>

<hr class="wp-header-end">
<form name="frmsearch" id="frmsearch" action="<?php echo add_query_arg( array( 'wdes_name' => $wdes_name )) ;?>" method="Post">
<table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
<tr>
<td align="right" style="padding: 10px 2px;" >Search <input type="text" name="wdes_name" id="wdes_name" value="<?php echo $wdes_name;?>" placeholder="Enter Title here....">&nbsp;
<input type="submit" class="page-title-action" name="btnsearch" id="btnsearch" value="Search"/>
<input type="button" class="page-title-action" name="btnall" id="btnall" value="View all" onclick="return view_all('<?php echo  $siteurl;?>/wp-admin/admin.php?page=designation&action=deswording');"/> 
</td></tr>
</table>
</form>
</div>
<form id="posts-filter" method="post">
<input type="hidden" name="wordingredirecturl" id="wordingredirecturl" value="<?php echo $deswording ;?>">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Wording Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>PDF File Name</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Senarios Title</span><span class="sorting-indicator"></span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Action</span><span class="sorting-indicator"></span></a></th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($allwording)>0){
			foreach($allwording as $allw){
			$wid=$allw->id;
			$desg_id=$allw->desg_id;
			$catid=$allw->catid;
			$subcatid=$allw->subcatid;	
			$awmurl=$adminurl."admin.php?page=designation&action=wordmeta&type=new&wid_ID=$wid";
			$addwmurl='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Manage Wording Meta</a>';
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="<?php echo $adminurl;?>admin.php?page=designation&action=deswording&type=edit&w_ID=<?php echo $wid; ?>&desg_id=<?php echo $desg_id; ?>" aria-label="“a” (Edit)"><?php echo $allw->title;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=deswording&type=edit&w_ID=<?php echo $wid; ?>&desg_id=<?php echo $desg_id; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> |
				<span class="delete">
<a role="button" onclick="return delete_wording('wording','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $wid ;?>','deletewording');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> | </span></div>
	</td>
		<td><?php echo deslistpdfname($desg_id);?></td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo deslist($desg_id);?></span></td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text">
			<?php echo $addwmurl; ?>
			</span></div>
			</td></tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totals/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</div>
</section>
<?php } //****************************//

if($_GET['action']=="wordmeta" && $_GET['page']=="designation"){ 
    if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }
$Alld = "SELECT * FROM $table_wording_meta";
$wordingmeta = $wpdb->get_results($Alld);
$totalwm = count($wordingmeta);
?>
<section id="projecttypelist" class="tabcontent1">
<div class="col-wrap">
<h3 class="wp-heading-inline">Wording Meta data of the Designations</h3>
<hr class="wp-header-end">
</div>
<form id="posts-filter" method="post">
<input type="hidden" name="metaredirecturl" id="metaredirecturl" value="<?php echo $wordmeta;?>">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Meta Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>PDF File Name</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Wording Title</span><span class="sorting-indicator"></span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Value</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Condition</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($allwordingmeta)>0){
			foreach($allwordingmeta as $allwm){
			$mid=$allwm->id;
			$word_id=$allwm->word_id;
			$sqlq="select a.desg_id FROM wp_wording a WHERE a.id ='".$word_id."'";
			$wordingmetaq = $wpdb->get_results($sqlq);
        	$desg_id=$wordingmetaq[0]->desg_id;
			$awmcurl=$adminurl."admin.php?page=designation&action=metaconditon&type=new&metaid_ID=$mid";
			$addwmcurl='<a class="page-title-action" id="addnewurl" href="'.$awmcurl.'">Manage Condition</a>';
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&mw_ID=<?php echo $word_id; ?>&type=edit&wm_ID=<?php echo $mid; ?>" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&mw_ID=<?php echo $word_id; ?>&type=edit&wm_ID=<?php echo $mid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span>
				<span class="delete">
<a role="button" onclick="return delete_wordmeta('wording_meta','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $mid;?>','deletewordingmeta');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> | </span></div>
	</td>	
		<td><?php echo deslistpdfname($desg_id);?></td>

			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo wmlist($word_id);?></span></td>
			<td class="description column-description" data-colname="Description"><?php echo $allwm->value;?></td>
			<td class="description column-description" data-colname="Description">
			<?php echo $addwmcurl;?>
			</td>
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totalwm/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</div>
</section>
<?php }

if($_GET['action']=="metaconditon" && $_GET['page']=="designation"){ 
$table_meta_conditions=$wpdb->prefix.'meta_conditions';
$table_neta_conditionsvalue=$wpdb->prefix.'meta_conditions_value';
    if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }
$Alld = "SELECT * FROM $table_meta_conditions";
$wordingmeta = $wpdb->get_results($Alld);
echo $totalwm = count($wordingmeta);
?>
<section id="projecttypelist" class="tabcontent1">
<div class="col-wrap">
<h3 class="wp-heading-inline">Wording Meta Condition of the Designations</h3>
<hr class="wp-header-end">
</div>
<form id="posts-filter" method="post">
<input type="hidden" name="metaredirecturl" id="metaredirecturl" value="<?php echo $wordmeta;?>">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Condition Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>PDF File Name</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Wording Title</span><span class="sorting-indicator"></span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Value</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Condition</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($allwordingmeta)>0){
			foreach($allwordingmeta as $allwm){
			$mid=$allwm->id;
			$word_id=$allwm->word_id;
			$sqlq="select a.desg_id FROM wp_wording a WHERE a.id ='".$word_id."'";
			$wordingmetaq = $wpdb->get_results($sqlq);
        	$desg_id=$wordingmetaq[0]->desg_id;
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&mw_ID=<?php echo $word_id; ?>&type=edit&wm_ID=<?php echo $mid; ?>" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&mw_ID=<?php echo $word_id; ?>&type=edit&wm_ID=<?php echo $mid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span>
				<span class="delete">
<a role="button" onclick="return delete_wordmeta('wording_meta','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $mid;?>','deletewordingmeta');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> | </span></div>
	</td>	
		<td><?php echo deslistpdfname($desg_id);?></td>

			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo wmlist($word_id);?></span></td>
			<td class="description column-description" data-colname="Description"><?php echo $allwm->value;?></td>
			<td class="description column-description" data-colname="Description">
			<a href="<?php echo $adminurl;?>admin.php?page=designation&action=metaconditon&type=new&metaid_ID=<?php echo $word_id; ?>" ><?php echo _e('Add/View');?>
			</td>
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totalwm/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</div>
</section>
<?php } ?>
</div><!-----------Wrapper-------->
</div><!-----------Primary & Cintent Area-------->
