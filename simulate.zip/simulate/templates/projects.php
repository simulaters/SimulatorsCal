<?php 
ob_start();
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$siteurl = get_option("siteurl");
//$currentuserid=get_current_user_id();
$user=wp_get_current_user();
if(in_array("administrator", $user->roles)){
$WHERES="";
}
else
{
$WHERES="AND  userid='".$currentuserid=$user->ID."'";
}
//===============Delete Records============//
$eid = isset($_GET['id'])?$_GET['id']:"";
$redirectmyprojectslink = $adminurl."admin.php?page=simulate_projects";
if(!empty($eid)){
	//Delete Meta Wordings
	$SQLMETAWORDINGS = "DELETE FROM wp_project_meta_wording WHERE project_id='".$eid."'";
	$wpdb->query($SQLMETAWORDINGS);			
	//Delete Meta
	$SQLMETA = "DELETE FROM wp_project_meta WHERE project_id='".$eid."'";
	$wpdb->query($SQLMETA);		  
	 $SQL = "DELETE FROM wp_projects WHERE id='".$eid."'";
	 $wpdb->query($SQL);
	$_SESSION['SuccessMsg'] = "Record Deleted Successfully.....";
	$_SESSION['id']="success";
	wp_redirect($redirectmyprojectslink);	
	exit; 
 }
//===============Delete Records============//

$table_name = $wpdb->prefix . "projects";
$table_prefix = $wpdb->prefix;
$items_per_page =20;
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ($page * $items_per_page) - $items_per_page;
$plistid = isset($_GET['plistid'])?$_GET['plistid']:"";
$SQLTOTAL = "SELECT * FROM wp_projects ".$WHERES." ORDER BY id DESC";
$rsTotals = $wpdb->get_results($SQLTOTAL);
$total = count($rsTotals);
if(!empty($plistid)){
$SQL = "SELECT * FROM wp_projects WHERE pt_id='".$plistid."'  ".$WHERES." 
		ORDER BY id DESC
		LIMIT ".$offset.",".$items_per_page."";
    
}else{
$plistid=1;
$SQL = "SELECT * FROM wp_projects WHERE pt_id='".$plistid."'  ".$WHERES." 
ORDER BY id DESC
LIMIT ".$offset.",".$items_per_page."";   
}
				 
$SQLPT = "SELECT * FROM wp_project_type ORDER BY id DESC";
$projectT = $wpdb->get_results($SQLPT);
$rs = $wpdb->get_results($SQL);
function get_operations($project_id){
	global $wpdb;
	$SQLMETA = "SELECT COUNT(project_id) AS TOTAL  FROM wp_project_meta WHERE project_id='".$project_id."'";
	$rsTotal = $wpdb->get_results($SQLMETA);
	$totals = $rsTotal[0]->TOTAL;
	return $totals;	
}	   
 if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }?>

<script type="text/javascript">
jQuery(document).ready(function(){
$("#<?php echo $_SESSION['id'];?>").show(1).delay(6000).hide('slow');
$("#resultM").show(1).delay(6000).hide('slow');

});



</script>
<div class="mem_vid1">
</div>
<div class="mainform plist">
<div class="wraper">
<div class="tab notab">
 
</div>
<div class="main_project">
<label>Select Project Type:</label>
<select style="width: 280px"  id="plistid" name="plistid" onChange="window.location='admin.php?page=simulate_projects&plistid='+this.value">
 <option value="">Please Select</option>
<?php 
$selectedname=array();
if(count($projectT)>0){
foreach($projectT as $pt){
     $selected=($pt->id == $plistid)? "selected" : "";
if($pt->id == $plistid)
{
    $selectedname[]= $pt->name;
}
echo '<option '.$selected.' value="'.$pt->id.'">'.$pt->name.'</option>';
?>
<?php }} ?>
</select>

  <h3 class="opt_hg"><?php echo $selectedname[0]; ?></h3>
  <?php if($total>0){?>
  <div class="pge_nmbr">
				  <?php echo  paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '<li></li>',
       'total' => ceil($total/$items_per_page),
        'current' => $page,
         'prev_text'          => __( 'Previous' ),
    'next_text'          => __( 'Next'),
    'type' => 'list'
    )); ?></div>
	<?php }?>
<form class="frmdatas" name="frmdata" id="frmdata" method="post" action="">

<table class="table_a smpl_tbl prjct_tble"> 
<?php if(count($rs)>0){
    ?>
<tr>
 <td>Date</td>
 <td>Name</td>
 <td>Description</td>
 <td>No of operations</td>
 <td>Total EEC</td>
 <td>Validation of EWCs</td>
 <td>Cost min. Works</td>
 <td>Max cost Works</td>
 <td>Average coverage rate</td>
 <td>Action</td>
</tr> 
 <?php 
	for($i=0;$i<count($rs);$i++){
		$total_operations = get_operations($rs[$i]->id);
	?>
  <tr>
 <td><?php echo date("d/m/Y",strtotime($rs[$i]->created));?></td>
 <td><?php echo $rs[$i]->name;?></td>
 <td><?php echo $rs[$i]->description;?></td>
 <td><?php echo $total_operations;?></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td>
 <img id="btnlinks" src="<?php echo $siteurl;?>/wp-content/uploads/2018/02/delete.png" onclick="return deletest('<?php echo $redirectmyprojectslink;?>','<?php echo $rs[$i]->id;?>');">
 </td>
</tr> 
 <?php }
 }else{?>
 <tr id="notfound"><td>No Projects Found</td></tr>
 <?php } ?>
</table> 
</form> 
</div>
 
<div class="clr"></div>

</div>
<!-- The Modal -->
<script type='text/javascript'>

function deletest(url,ids)
{
if(confirm("Do you want to delete?")){
document.location.href=""+url+"&id="+ids+"";
}	 
}

</script>
