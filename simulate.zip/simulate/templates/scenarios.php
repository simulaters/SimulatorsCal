<?php 
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
$aurl=$adminurl."admin.php?page=designation&type=new&action=designation";
$addurl='<a class="page-title-action" id="addnewurls" href="'.$aurl.'">Add New Scenario</a>';
/**********DB Tables******************************/
$table_category = $wpdb->prefix . "categories";
$table_subcategory= $wpdb->prefix . "subcategory";
$table_desig = $wpdb->prefix . "designations";
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";
$table_neta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
/**********DB Tables End Here******************************/

if(isset($_REQUEST['des_name'])){
global $wpdb;
$des_name=$_REQUEST['des_name'];
$WHERE = "WHERE des_name LIKE '%".trim($_REQUEST['des_name'])."%' OR number LIKE '%".trim($_REQUEST['des_name'])."%' OR id LIKE '%".trim($_REQUEST['des_name'])."%'";
$Alld = "SELECT * FROM ".$table_desig."  ".$WHERE." ORDER BY id DESC";
$alldesignations = $wpdb->get_results($Alld);
//print_r($alldesignations);
$DESIGID=$alldesignations[0]->id;
$catids=$alldesignations[0]->catid;
$subcatid=$alldesignations[0]->subcatid;
}

function sectorsname($catids){
global $wpdb;
$table_category = $wpdb->prefix . "categories";
$allsectors = "SELECT * FROM $table_category ORDER BY id DESC";
$sectorlist = $wpdb->get_results($allsectors);?>
<select id="sectors"  class="subsectors" onchange="return showSubcat(this.value,'<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','subcategory')" name="sectorslist" id="sectorslist">
<?php foreach($sectorlist as $sectors):
if($catids==$sectors->id){ $selected="selected";}else{ $selected=""; } ?>
<option value="<?php echo $sectors->id;?>" <?php echo $selected; ?> id="<?php echo $ids; ?>"><?php echo $sectors->category_name;?></option>
<?php endforeach;?>
</select>
<?php } 
function rspecial($string,$rp = '') {
    $string = str_replace(' ', ',', $string);
    return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
  }

function subsectorsname($subcatid,$catids){
			global $wpdb;
			if(isset($catids)){
			$WHEREs = "WHERE catid =$catids";
			$table_subcategory= $wpdb->prefix . "subcategory";
			$SQLcatp="SELECT * FROM $table_subcategory ".$WHEREs."  ORDER BY id DESC";
			$result = $wpdb->get_results($SQLcatp); 
			} ?>
			<label>Sub Sectors</label>
			<select id="subsectors" name="subsectors" class="subsectors" onchange="return showDesignation(this.value,'<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','designations')">
			<?php foreach($result as $row) { 
			if($subcatid==$row->id){ $selected="selected";}else{ $selected=""; }
			?><option value="<?php echo $row->id;?>" <?php echo $selected; ?> ><?php echo $row->category_name;?></option>
			<?php } ?>
			</select>
<?php }

function designationlist($did,$subcatid){
			global $wpdb;
			$table_desig = $wpdb->prefix . "designations";
			$SQLcatp="SELECT * FROM ".$table_desig."  WHERE subcatid ='$subcatid' ORDER BY id DESC";
			$result = $wpdb->get_results($SQLcatp);
			$catid = $result[0]->catid; ?>
			<label>Title :</label>
			<select id="design" name="fiche" onchange="return getdestinationsdata(this.value,<?php echo $catid;?>,'<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','designations')" id="fiche<?php echo $catid;?>">
			<?php foreach($result as $row){
			if($did==$row->id){ $selected="selected";}else{ $selected=""; } ?>
			<option value="<?php echo $row->id;?>" <?php echo $selected; ?>><?php echo stripslashes($row->number);?></option>
			<?php } ?>
			</select>
<?php 	} ?>
<!---------------------Scenario  List Here------------>
<div id="primary" class="content-area">
<div id="wrapper" class="wrap">
<section id="scenariolist" class="tabcontent1">
<div class="col-wrap">
<hr class="wp-header-end">
<form name="frmsearch" id="searchsenario" action="" method="Post">
<table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
<tr>
<td id="searchtab" align="right" >Search <input type="text" name="des_name" id="des_name" value="" placeholder="Enter Title or pdf name here....">&nbsp;
<input type="button" onclick="return SearchDesignation('<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','designations')" class="page-title-action" name="btnsearch" id="btnsearch" value="Search"/>
<p>Search the Scenario by title or pdf file name (BAR-EN-103)</p>
</td>
<td><?php echo $addurl; ?></td>
</tr>
</table>
</form>
</div>
</section>
<section id="scenariocatlist" class="tabcontent1">
<div id="sectorslist">
<label>Sectors : </label>
<?php echo sectorsname($catids);?>
</div>
<div id="txtHints">
<?php echo subsectorsname($subcatid,$catids);?>
</div>
<div id="senariopdflist">
<?php echo designationlist($DESIGID,$subcatid,$catids);?>
</div>
</section>
<?php 
$adminurl = admin_url();
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
$SQLdesg="SELECT * FROM wp_designations WHERE id ='".$DESIGID."'";
$resultdesg = $wpdb->get_results($SQLdesg);
$designid=$resultdesg[0]->id;
$catid = $resultdesg[0]->catid;
$SQLcatvalue="SELECT * FROM wp_categories  WHERE id ='$catid' ORDER BY id DESC";
$catvalcurr = $wpdb->get_results($SQLcatvalue);
//print_r($catvalcurr);
$catprimevalue= $catvalcurr[0]->prime_value;
$catprimecurr=$catvalcurr[0]->prime_currency;
?>
<div id="resultlistd">
<?php
echo '<div id="detailsscenario">';
echo '<a href="'.get_site_url().'/wp-admin/admin.php?page=designation&action=designation&type=edit&d_ID='.$resultdesg[0]->id.'">
<img src="'.get_site_url().'/wp-content/uploads/2018/03/editlink.png"></a>';
if($resultdesg[0]->number){
	$target = get_site_url()."/wp-content/plugins/simulate/uploads/".$resultdesg[0]->number;
    $resultCS =  basename($resultdesg[0]->number, ".pdf");
	echo '<p><a target="_blank" href="'.$target.'"><font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.$resultCS.'</font></font></a></p>';
}
if($resultdesg[0]->des_name){
echo '<p><b>'.stripslashes($resultdesg[0]->des_name).'</b></p>';
}
echo '</div>';
if($resultdesg[0]->conditions){
echo '<div id="senariodescription">';
echo '<a href="'.get_site_url().'/wp-admin/admin.php?page=designation&action=designation&type=edit&d_ID='.$resultdesg[0]->id.'">
<img src="'.get_site_url().'/wp-content/uploads/2018/03/editlink.png"></a>';
echo '<p><font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.stripslashes($resultdesg[0]->conditions).'</font></font></p>';
echo '</div>';
}
echo '<div id="senariometa">';
?>

<section id="projecttypelist" class="tabcontent1">
<form id="posts-filter" method="post">
<h3 style="clear: both; float: left;">Wording Title : </h3>
<img id="addword" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png" onclick="addnewwording('Submit','<?php echo plugins_url('ajaxfiles/editwording.php' ,dirname(__FILE__));?>','','<?php echo $designid ;?>')"> 
<?php if($catprimevalue){?>
<span class="sa_extra"><label>General Prime Value: </label><b><?php echo $catprimevalue;?> <?php echo $catprimecurr;?></b></span>
<?php } ?>
<?php 
echo get_designationfiles($DESIGID);
?>
</form>
</section>
</div>
		<div class="hover_bkgr_fricc">
		<span class="helper"></span>
		<div>
		<div onclick="closenewwording()" class="popupCloseButton">X</div>
		<div id="forms2" class="wrap">
		</div>
		</div>
		</div>
		</div>
		</div>
</div><!--Wrapper-->
</div><!--primary-->