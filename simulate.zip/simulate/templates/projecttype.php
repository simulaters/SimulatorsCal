<?php 
global $wpdb;
@session_start(); 
$adminurl = admin_url();
$siteurl = get_option("siteurl");
$tablename= $wpdb->prefix . "project_type";
$tpt= $wpdb->prefix . "project_subtype";
$wsprice= $wpdb->prefix . "ewc_selling_price";
$current_date = date("Y-m-d H:i:s");
//===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;

$ptypes=$adminurl."admin.php?page=project_type&action=ptypes";
$tpts=$adminurl."admin.php?page=project_type&action=tpt";
$sprice=$adminurl."admin.php?page=project_type&action=sprice";

$ptaddurl='<a class="page-title-action" id="addnewurl" href="'.$ptypes.'&type=new">Add Project Type</a>';
$staddurl='<a class="page-title-action" id="addnewurl" href="'.$tpts.'&type=new">Add Sub Type</a>';
$spaddurl='<a class="page-title-action" id="addnewurl" href="'.$sprice.'&type=new">New Selling Price </a>';
//-------------Project Type Section Add here-----------//
if($_GET['action']=="ptypes"){
$SQLcat = "SELECT * FROM $tablename";
$allCategoriesc = $wpdb->get_results($SQLcat);
$total = count($allCategoriesc);
if($_GET['type']=='delete' && $_GET['action']=="ptypes"){
			$delids=$_GET['tid'];
			$SQLD = "DELETE FROM $tablename WHERE id =$delids";
			$Del=$wpdb->query($SQLD);
			if($Del){
			$_SESSION['id']="success";
			$_SESSION['SuccessMsg']="Record Deleted Successfully";
			wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=ptypes");	
			exit; 
			}else{
			$_SESSION['id']="error";
			$_SESSION['SuccessMsg']="Record Deleted Error";
			}
}
if($_GET['type']=='edit' && $_GET['action']=="ptypes"){
				$title="Edit Project Type";
				$buttontext="Update";
				$editids=$_GET['tid'];
				$SQLecat = "SELECT * FROM $tablename WHERE id  LIKE '%".$editids."%'";
				$edCat = $wpdb->get_results($SQLecat);
				$eid=$edCat[0]->id;
				if(isset($_POST['Update'])){
				$typename=$_POST['typename'];
				$pdescription=$_POST['pdescription'];
				$SQLup = "UPDATE ".$tablename." SET name='".$typename."',description='".$pdescription."',modify='".$current_date."' WHERE id='".$eid."'";
				$c=$wpdb->query($SQLup);
				if($c){
				$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=ptypes");	
				exit;
				}
				}
	
}
if($_GET['type']=='new' && $_GET['action']=="ptypes"){
		$title="Add Project Type";
		$buttontext="Submit";
		if(isset($_REQUEST['Submit'])){
		$typename=$_POST['typename'];
		$pdescription=$_POST['pdescription'];
		if(empty($typename)){
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter Type name....";	
		}else
		{
		$SQL = "SELECT * FROM $tablename WHERE name  LIKE '%".$typename."%'";
		$rsSubject = $wpdb->get_results($SQL);
		if(empty($rsSubject)){	
		$data=array('name' => $typename,'description' =>$pdescription,'status' => 'Active','created' => $current_date);
		$insert=$wpdb->insert( $tablename, $data);
		if($insert){
		$_SESSION['id']="success";
		$_SESSION['SuccessMsg']="Data added Successfully";
		wp_redirect($adminurl."admin.php?page=project_type&action=ptypes");	
		exit;
		}else{
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Data not added Successfully";					
		}
		}		
		}
		}
}
$ptype='';
$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
}
if($_GET['action']==""){
$ptype='ptype';
$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
}
$RESULTS=$wpdb->get_results($SQLcatp);

//-------------Type Project Type Section Add here-----------//
if($_GET['action']=="tpt"){
	$SQLcat = "SELECT * FROM $tpt";
$allCategoriesc = $wpdb->get_results($SQLcat);
$total = count($allCategoriesc);
if($_GET['type']=='delete' && $_GET['action']=="tpt"){
			$delids=$_GET['tid'];
			$SQLD = "DELETE FROM $tpt WHERE id =$delids";
			$Del=$wpdb->query($SQLD);
			if($Del){
			$_SESSION['id']="success";
			$_SESSION['SuccessMsg']="Record Deleted Successfully";
			wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=tpt");	
			exit; 
			}else{
			$_SESSION['id']="error";
			$_SESSION['SuccessMsg']="Record Deleted Error";
			}
}
if($_GET['type']=='edit' && $_GET['action']=="tpt"){
	global $wpdb;
				$title="Edit Sub Type";
				$buttontext="Update";
				$editidss=$_GET['tid'];
				$SQLe = "SELECT * FROM $tpt WHERE id  LIKE '%".$editidss."%'";
				$edTPT = $wpdb->get_results($SQLe);
				echo $eid=$edTPT[0]->id;
				if(isset($_POST['Update'])){
				$tptname=$_POST['tptname'];
				$tptdescription=$_POST['tptdescription'];
				 $parenttp=$_POST['parenttype'];
				$SQLup = "UPDATE ".$tpt." SET parent_pt_id='".$parenttp."',title='".$tptname."',description='".$tptdescription."',modify='".$current_date."' WHERE id='".$eid."'";
				$c=$wpdb->query($SQLup);
				if($c){
				$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=tpt");	
				exit;
				}else{
					$_SESSION['id']="error";
				$_SESSION['SuccessMsg']="Record not Updated! ";
					
				}
				}
	
}
if($_GET['type']=='new' && $_GET['action']=="tpt"){
		$title="Add Sub Type";
		$buttontext="Submit";
		if(isset($_REQUEST['Submit'])){
		$tptname=$_POST['tptname'];
		$tptdescription=$_POST['tptdescription'];
		$parenttp=$_POST['parenttype'];
		if(empty($tptname)){
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter Type name....";	
		}else
		{
		$SQL = "SELECT * FROM $tpt WHERE title  LIKE '%".$tptname."%'";
		$rsSubject = $wpdb->get_results($SQL);
		if(empty($rsSubject)){	
		$datas=array('parent_pt_id' => $parenttp,'title' => $tptname,'description' =>$tptdescription,'status' => 'Active','created' => $current_date);
		$insert=$wpdb->insert( $tpt, $datas);
		if($insert){
		$_SESSION['id']="success";
		$_SESSION['SuccessMsg']="Data added Successfully";
		wp_redirect($adminurl."admin.php?page=project_type&action=tpt");	
		exit;
		}else{
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Data not added Successfully";					
		}
		}		
		}
		}
}
$SQLcatp = "SELECT * FROM $tpt  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$tptRESULTS=$wpdb->get_results($SQLcatp);	
}
//-------------Selling Price Section Start here-----------//
if($_GET['action']=="sprice"){
 if($_GET['type']=='new' && $_GET['action']=="sprice"){
		$title="Add Selling Price";
		$buttontext="Submit";
		if(isset($_REQUEST['Submit'])){
		$units=$_POST['units'];
		$uprice=$_POST['uprice'];
		if(empty($units)){
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter unit name....";	
		}else
		{
$SQL = "SELECT * FROM $wsprice WHERE unit  LIKE '%".$units."%'";
		$rspSubject = $wpdb->get_results($SQL);
		if(empty($rspSubject)){	
		$sp=array('unit' => $units,'price' =>$uprice,'status' => 'Active','created' => $current_date);
		$insert=$wpdb->insert( $wsprice, $sp);
		if($insert){
		$_SESSION['id']="success";
		$_SESSION['SuccessMsg']="Data added Successfully";
		wp_redirect($adminurl."admin.php?page=project_type&action=sprice");	
		exit;
		}else{
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Data not added Successfully";					
		}
		}		
		}
		}
}
if($_GET['type']=='edit' && $_GET['action']=="sprice"){
	global $wpdb;
				$title="Edit Sub Type";
				$buttontext="Update";
				$editidsp=$_GET['tid'];
				$SQLe = "SELECT * FROM $wsprice WHERE id  LIKE '%".$editidsp."%'";
				$edTPT = $wpdb->get_results($SQLe);
				$eid=$edTPT[0]->id;
				if(isset($_POST['Update'])){
                $units=$_POST['units'];
                $uprice=$_POST['uprice'];
				$SQLup = "UPDATE ".$wsprice." SET price='".$uprice."',unit='".$units."',modify='".$current_date."' WHERE id='".$eid."'";
				$c=$wpdb->query($SQLup);
				if($c){
				$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=sprice");	
				exit;
				}else{
					$_SESSION['id']="error";
				$_SESSION['SuccessMsg']="Record not Updated! ";
					
				}
				}
	
}
if($_GET['type']=='delete' && $_GET['action']=="sprice"){
			$delidsp=$_GET['tid'];
			$SQLDs = "DELETE FROM $wsprice WHERE id =$delidsp";
			$Del=$wpdb->query($SQLDs);
			if($Del){
			$_SESSION['id']="success";
			$_SESSION['SuccessMsg']="Record Deleted Successfully";
			wp_redirect($siteurl."/wp-admin/admin.php?page=project_type&action=sprice");	
			exit; 
			}else{
			$_SESSION['id']="error";
			$_SESSION['SuccessMsg']="Record Deleted Error";
			}
}
$SQLsp = "SELECT * FROM $wsprice  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$spRESULTS=$wpdb->get_results($SQLsp);
}
//-------------Selling Price Section End here-----------//	
?>
<script type="text/javascript">
jQuery(document).ready(function(){
    $("#<?php echo $_SESSION['id'];?>").show(1).delay(6000).hide('slow');
	});
</script>
<div id="primary" class="content-area">
<div id="wrapper" class="wrap">
<div class="tab">
<?php 
    
if( $_GET['action']=="ptypes" || $ptype=="ptype"){
?>
<a href="<?php echo $ptypes;?>" class="tablinks active">Project Type4</a>
<?php }else{ ?>
<a href="<?php echo $ptypes;?>" class="tablinks ">Project Type4</a>
<?php } 
 if($_GET['action']=="tpt"){
?>
<a href="<?php echo $tpts;?>" class="tablinks active">Sub Type</a>
<?php }else{ ?>
<a href="<?php echo $tpts;?>" class="tablinks ">Sub Type</a>
<?php } 
 if($_GET['action']=="sprice"){
?>
<a href="<?php echo $sprice;?>" class="tablinks active">Selling Price</a>
<?php }else{ ?>
<a href="<?php echo $sprice;?>" class="tablinks ">Selling Price</a>
<?php }  ?>
</div>
<?php if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php } ?>
<?php if($_GET['action']=="ptypes" || $ptype=='ptype'){ ?>
<section id="projecttypelist" class="tabcontent1">
<?php if($_GET['type']=='edit' || $_GET['type']=='new'){ ?>
<h3><?php echo $title?$title:"";?></h3>
<form action="" method="POST">
<p><label>Type Name: </label><input type="text" name="typename" id="typename" value="<?php echo $edCat[0]->name?$edCat[0]->name:$typename; ?>"></p>
<p><label>Description: </label><input type="text" name="pdescription" id="pdescription" value="<?php echo $edCat[0]->description?$edCat[0]->description:$pdescription; ?>"></p>
<p><label></label><input type="submit" class="btn btn-info"  name="<?php echo $buttontext;?>" value="<?php echo $buttontext;?>" id="submit"></p>
</form>

<?php 
}else{
	echo $ptaddurl; ?>
<table class="myprojects">
<h5>Project Type Lists</h5>
<thead>
<tr>
<th>id</th>
<th>Date</th>
<th>Name</th>
<th>Description</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($RESULTS as $rs){ 
$aurle=$adminurl."admin.php?page=project_type&action=ptypes&type=edit&tid=".$rs->id."";
$aurld=$adminurl."admin.php?page=project_type&action=ptypes&type=delete&tid=".$rs->id."";
$edit='<a class="page-title-action" id="addnewurl" href="'.$aurle.'">Edit</a>';
$delete='<a class="page-title-action" id="addnewurl" href="'.$aurld.'">Delete</a>';
$status= $rs->status; ?>
<tr>
<td><?php echo $rs->id ?></td>
<td><?php echo $rs->created; ?></td>
<td><?php echo $rs->name ?></td>
<td><?php echo $rs->description ?></td>
<td>
<select style="width:108px;" name="post_status" id="post_status" onchange="return change_status(this.value,'<?php echo $rs->id;?>','<?php echo plugins_url('inc/update_status.php' ,dirname(__FILE__));?>','project_type')">

<option value="Active" <?php if($status=="Active"){?>selected<?php }?>>Active</option>
<option value="Inactive" <?php if($status=="Inactive"){?>selected<?php }?>>Inactive</option>		 	 
</select>
</td>
<td><?php echo $edit;?></td>
<td><?php echo $delete; ?></td>
</tr>
<?php 
}
?>
</tbody>
</table>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
<?php } ?>
</section>
<?php } 

/***********************Type Project Type Start here****************************/
if($_GET['action']=="tpt"){ ?>
	<section id="projecttypelist" class="tabcontent1">
<?php if($_GET['type']=='edit' || $_GET['type']=='new'){ ?>
<h3><?php echo $title?$title:"";?></h3>
<form action="" method="POST">
<p><label>Parent Type : </label>
<select name="parenttype" id="parenttype">
<option value="">Select Type</option>
<?php foreach($RESULTS as $rst) {?>
<option value="<?php echo $rst->id; ?>" <?php echo $edTPT[0]->id==$rst->id?'selected':''; ?> ><?php echo $rst->name; ?></option>
<?php } ?>
</select>
</p>
<p><label>Sub Type Name: </label><input type="text" name="tptname" id="tptname" value="<?php echo $edTPT[0]->title?$edTPT[0]->title:$tptname; ?>"></p>
<p><label>Description: </label><input type="text" name="tptdescription" id="tptdescription" value="<?php echo $edTPT[0]->description?$edTPT[0]->description:$tptdescription; ?>"></p>
<p><label></label><input type="submit" class="btn btn-info"  name="<?php echo $buttontext;?>" value="<?php echo $buttontext;?>" id="submit"></p>
</form>
<?php }else{ 
echo $staddurl; ?>
<table class="myprojects">
<h4>Project Sub Type Lists</h4>
<thead>
<tr>
<th>id</th>
<th>Date</th>
<th>Name</th>
<th>Description</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($tptRESULTS as $rs){ 
$aurle=$adminurl."admin.php?page=project_type&action=tpt&type=edit&tid=".$rs->id."";
$aurld=$adminurl."admin.php?page=project_type&action=tpt&type=delete&tid=".$rs->id."";
$edit='<a class="page-title-action" id="addnewurl" href="'.$aurle.'">Edit</a>';
$delete='<a class="page-title-action" id="addnewurl" href="'.$aurld.'">Delete</a>';
$status= $rs->status; ?>
<tr>
<td><?php echo $rs->id ?></td>
<td><?php echo $rs->created; ?></td>
<td><?php echo $rs->title ?></td>
<td><?php echo $rs->description ?></td>
<td>
<select style="width:108px;" name="post_status" id="post_status" onchange="return change_status(this.value,'<?php echo $rs->id;?>','<?php echo plugins_url('inc/update_status.php' ,dirname(__FILE__));?>','project_subtype')">
<option value="Active" <?php if($status=="Active"){?>selected<?php }?>>Active</option>
<option value="Inactive" <?php if($status=="Inactive"){?>selected<?php }?>>Inactive</option>		 	 
</select>
</td>
<td><?php echo $edit;?></td>
<td><?php echo $delete; ?></td>
</tr>
<?php 
}
?>
</tbody>
</table>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
<?php } ?>
</section>
<?php }

/***********************Selling Price Section Start here****************************/
 if($_GET['action']=="sprice"){ ?>
<section id="sellingprice" class="tabcontent1 ">
<?php if($_GET['type']=='edit' || $_GET['type']=='new'){ ?>
<h3><?php echo $title?$title:"";?></h3>
<form action="" method="Post">
<p><label>Units: </label><input type="text" name="units" id="units" value="<?php echo $edTPT[0]->unit?$edTPT[0]->unit:$uprice; ?>"></p>
<p><label>Price: </label><input type="text" name="uprice" id="uprice" value="<?php echo $edTPT[0]->price?$edTPT[0]->price:$uprice; ?>"></p>
<p><label></label><input type="submit" class="btn btn-info"  name="<?php echo $buttontext;?>" value="<?php echo $buttontext;?>" id="submit"></p>
</form>
</section>
<?php }else{
echo $spaddurl; ?>
<table class="myprojects">
<h4>Selling Price Lists</h4>
<thead>
<tr>
<th>id</th>
<th>Unit</th>
<th>Price</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
if(count($spRESULTS)){
foreach($spRESULTS as $rsp){ 
$saurle=$adminurl."admin.php?page=project_type&action=sprice&type=edit&tid=".$rsp->id."";
$saurld=$adminurl."admin.php?page=project_type&action=sprice&type=delete&tid=".$rsp->id."";
$edit='<a class="page-title-action" id="addnewurl" href="'.$saurle.'">Edit</a>';
$delete='<a class="page-title-action" id="addnewurl" href="'.$saurld.'">Delete</a>';
$status= $rsp->status; ?>
<tr>
<td><?php echo $rsp->id ?></td>
<td><?php echo $rsp->unit; ?></td>
<td><?php echo $rsp->price ?></td>
<td>
<select style="width:108px;" name="post_status" id="post_status" onchange="return change_status(this.value,'<?php echo $rsp->id;?>','<?php echo plugins_url('inc/update_status.php' ,dirname(__FILE__));?>','ewc_selling_price')">
<option value="Active" <?php if($status=="Active"){?>selected<?php }?>>Active</option>
<option value="Inactive" <?php if($status=="Inactive"){?>selected<?php }?>>Inactive</option>		 	 
</select>
</td>
<td><?php echo $edit;?></td>
<td><?php echo $delete; ?></td>
</tr>
<?php 
}}else{
    echo '<tr><p>No Record Found!</p></tr>';
    }
?>
</tbody>
</table>
<?php 
    }
} ?>
</div><!-----------Wrapper-------->
</div><!-----------Primary & Cintent Area-------->
