<?php 
global $wpdb;
@session_start(); 
$adminurl = admin_url();
$siteurl = get_option("siteurl");
$tablename= $wpdb->prefix . "project_type";
$current_date = date("Y-m-d H:i:s");
//===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;
$SQLcat = "SELECT * FROM $tablename";
$allCategoriesc = $wpdb->get_results($SQLcat);
$total = count($allCategoriesc);
//---------------------------------------//
$aurl=$adminurl."admin.php?page=project_type&action=types";
$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Add New Type</a>';
if($_GET['type']=='delete' && $_GET['action']=="types"){
			$delids=$_GET['tid'];
			$SQLD = "DELETE FROM $tablename WHERE id =$delids";
			$Del=$wpdb->query($SQLD);
			if($Del){
			$_SESSION['id']="success";
			$_SESSION['SuccessMsg']="Record Deleted Successfully";
			wp_redirect($siteurl."/wp-admin/admin.php?page=project_type");	
			exit; 
			}else{
			$_SESSION['id']="error";
			$_SESSION['SuccessMsg']="Record Deleted Error";
			}
}
if($_GET['type']=='edit' && $_GET['action']=="types"){
				$title="Edit Project Type";
				$buttontext="Update";
				$editids=$_GET['tid'];
				$SQLecat = "SELECT * FROM $tablename WHERE id  LIKE '%".$editids."%'";
				$edCat = $wpdb->get_results($SQLecat);
				$eid=$edCat[0]->id;
				if(isset($_POST['Update'])){
				$typename=$_POST['typename'];
				$pdescription=$_POST['pdescription'];
				$SQLup = "UPDATE ".$tablename." SET name='".$typename."',description='".$pdescription."',modify='".$current_date."' WHERE id='".$eid."'";
				$c=$wpdb->query($SQLup);
				if($c){
				$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($siteurl."/wp-admin/admin.php?page=project_type");	
				exit;
				}
				}
	
}else{
		$title="Add Project Type";
		$buttontext="Submit";
		if(isset($_REQUEST['Submit'])){
		$typename=$_POST['typename'];
		$pdescription=$_POST['pdescription'];
		if(empty($typename)){
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter Type name....";	
		}else
		{
		$SQL = "SELECT * FROM $tablename WHERE name  LIKE '%".$typename."%'";
		$rsSubject = $wpdb->get_results($SQL);
		if(empty($rsSubject)){	
		$data=array('name' => $typename,'description' =>$pdescription,'status' => 'Active','created' => $current_date);
		$insert=$wpdb->insert( $tablename, $data);
		if($insert){
		$_SESSION['id']="success";
		$_SESSION['SuccessMsg']="Data added Successfully";
		wp_redirect($adminurl."admin.php?page=project_type");	
		exit;
		}else{
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Data not added Successfully";					
		}
		}		
		}
		}
}
?>
<div id="primary" class="content-area">
<div id="wrapper" class="wrap">
<?php if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }
$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$RESULTS=$wpdb->get_results($SQLcatp);
?>
<?php if($_GET['action']=='types'){ ?>
<section id="projecttype" class="tabcontent1">
<h3><?php echo $title?$title:"";?></h3>
<form action="" method="POST">
<p><label>Type Name: </label><input type="text" name="typename" id="typename" value="<?php echo $edCat[0]->name?$edCat[0]->name:$typename; ?>"></p>
<p><label>Description: </label><input type="text" name="pdescription" id="pdescription" value="<?php echo $edCat[0]->description?$edCat[0]->description:$pdescription; ?>"></p>
<p><label></label><input type="submit" class="btn btn-info"  name="<?php echo $buttontext;?>" value="<?php echo $buttontext;?>" id="submit"></p>
</form>
</section>
<?php 
}else{ ?>

<div class="tab">
<button class="tablinks" onclick="openCity(event, 'projecttypelist')">Project Type</button>
<button class="tablinks" onclick="openCity(event, 'Tpt')">TPT</button>
<button class="tablinks" onclick="openCity(event, 'sellingprice')">Selling Price</button>
</div>
<section id="projecttypelist" style="display:block;" class="tabcontent">
<?php echo $addurl; ?>
<table class="myprojects">
<h5>Project Type Lists</h5>
<thead>
<tr>
<th>id</th>
<th>Date</th>
<th>Name</th>
<th>Description</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($RESULTS as $rs){ 
$aurle=$adminurl."admin.php?page=project_type&action=types&type=edit&tid=".$rs->id."";
$aurld=$adminurl."admin.php?page=project_type&action=types&type=delete&tid=".$rs->id."";
$edit='<a class="page-title-action" id="addnewurl" href="'.$aurle.'">Edit</a>';
$delete='<a class="page-title-action" id="addnewurl" href="'.$aurld.'">Delete</a>';
$status= $rs->status; ?>
<tr>
<td><?php echo $rs->id ?></td>
<td><?php echo $rs->created; ?></td>
<td><?php echo $rs->name ?></td>
<td><?php echo $rs->description ?></td>
<td>
<select style="width:108px;" name="post_status" id="post_status" onchange="return change_status(this.value,'<?php echo $rs->id;?>','<?php echo plugins_url('inc/update_status.php' ,dirname(__FILE__));?>','project_type')">

<option value="Active" <?php if($status=="Active"){?>selected<?php }?>>Active</option>
<option value="Inactive" <?php if($status=="Inactive"){?>selected<?php }?>>Inactive</option>		 	 
</select>
</td>
<td><?php echo $edit;?></td>
<td><?php echo $delete; ?></td>
</tr>
<?php 
}
?>
</tbody>
</table>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
</section>

<section id="Tpt" class="tabcontent">
<h3>Sub Project Type</h3>
<form action="" method="Post">
<p><label>Type of Project Types: </label><input type="text" name="subtypename" id="subtypename"></p>
<p><label></label><input type="submit" class="btn btn-info" name="submit" value="<?php _e('Submit');?>" id="submit"></p>
</form>
</section>

<section id="sellingprice" class="tabcontent">
<h3>EWC selling price</h3>
<form action="" method="Post">
<p><label>Units: </label><input type="text" name="units" id="units"></p>
<p><label>Price: </label><input type="text" name="uprice" id="uprice"></p>
<p><label></label><input type="submit" class="btn btn-info" name="submit" value="<?php _e('Submit');?>" id="submit"></p>
</form>
</section>
<?php } ?>





</div><!-----------Wrapper-------->
</div><!-----------Primary & Cintent Area-------->
